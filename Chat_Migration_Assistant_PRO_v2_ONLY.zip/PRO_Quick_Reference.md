# 📋 Quick Reference: Chat Migration Assistant PRO v2.0

**2-страничная шпаргалка для быстрого использования**

---

## ⚡ БЫСТРЫЕ КОМАНДЫ

### Базовые:
```
"Создай checkpoint"                    → Базовый режим (4 файла)
"Авто checkpoint"                      → Автоматический режим
"Авто checkpoint + валидация"          → С проверкой качества
"Авто checkpoint + Git"                → С версионированием
```

### Информация:
```
"Метрики проекта"                      → Dashboard прогресса
"Токены"                               → Остаток контекста
"Прогресс"                             → % завершения
"Качество"                             → Quality score
```

### Специальные:
```
"BRIDGE chat N→N+1"                    → Связь между чатами
"Валидируй checkpoint"                 → Проверка готовности
"Восстанови checkpoint"                → Если забыли создать
"Шаблон для [тип проекта]"             → Специализированный
```

---

## 🎯 3 РЕЖИМА РАБОТЫ

### 1. Базовый (v1.0 совместимость)
- **Время:** 10-15 минут
- **Файлы:** 4 обязательных
- **Автоматизация:** Нет
- **Для:** Простых проектов (1-2 чата)

### 2. Автоматизированный (PRO)
- **Время:** 2-3 минуты
- **Файлы:** 4-8 автоматически
- **Автоматизация:** Полная
- **Для:** Средних проектов (3-10 чатов)

### 3. Enterprise
- **Время:** 5 минут
- **Файлы:** Полная инфраструктура
- **Автоматизация:** + Git + CI/CD
- **Для:** Больших проектов (10+ чатов)

---

## 🐍 PYTHON СКРИПТ

### Базовое использование:
```bash
python checkpoint_creator.py \
  --project-name "Мой Проект" \
  --chat-number 1 \
  --items-total 87 \
  --items-complete 18 \
  --output-dir ./checkpoint
```

### С валидацией:
```bash
python checkpoint_creator.py \
  --project-name "Мой Проект" \
  --chat-number 1 \
  --items-total 87 \
  --items-complete 18 \
  --output-dir ./checkpoint \
  --validate
```

### С Git:
```bash
python checkpoint_creator.py \
  --project-name "Мой Проект" \
  --chat-number 1 \
  --items-total 87 \
  --items-complete 18 \
  --output-dir ./checkpoint \
  --validate \
  --git-auto
```

### Параметры:
- `--project-name` — Название проекта
- `--chat-number` — Номер чата (1, 2, 3...)
- `--project-type` — Тип (documentation/development/analysis/design/research/legal)
- `--items-total` — Всего items
- `--items-complete` — Завершено items
- `--output-dir` — Куда сохранить
- `--validate` — Запустить валидацию
- `--git-auto` — Создать Git commit

---

## 📁 8 ТИПОВ ПРОЕКТОВ

| Тип | Когда использовать |
|-----|-------------------|
| **documentation** | Книги, статьи, гайды, туториалы |
| **development** | Приложения, библиотеки, API |
| **analysis** | Data science, исследования, статистика |
| **design** | UI/UX, brand identity, design systems |
| **research** | Academic papers, literature reviews |
| **legal** | Контракты, compliance, review |
| **marketing** | Кампании, контент, стратегии |
| **education** | Курсы, тренинги, сертификации |

---

## ✅ CHECKPOINT CHECKLIST

**Обязательные файлы (минимум 4):**
- [ ] MASTER_INDEX.md — Навигация
- [ ] METHODOLOGY.md — Стандарты
- [ ] CHECKPOINT_N.md — Сводка
- [ ] README_QUICK_START.md — Инструкции

**Опциональные:**
- [ ] FIRST_MESSAGE.txt — Готовый текст
- [ ] BRIDGE_ChatN_to_ChatN+1.md — Связи
- [ ] [Специализированные по типу проекта]

**Проверка:**
- [ ] Все файлы не пустые
- [ ] Нет TODO/placeholder
- [ ] Метрики указаны
- [ ] Первое сообщение готово
- [ ] Прогресс рассчитан

---

## 🆘 TOP-5 ПРОБЛЕМ

### 1. Контекст закончился внутри задачи
**Решение:** "Создай partial checkpoint для [задача]"

### 2. Забыли создать checkpoint
**Решение:** "Восстанови checkpoint из описания: [что было]"

### 3. Claude не следует методологии
**Решение:** "Стоп. Перечитай METHODOLOGY.md. Требования: [список]"

### 4. Качество падает
**Решение:** "Метрики качества" → исправить проблемные места

### 5. Потеряли файлы
**Решение:** Найти в истории чатов → Скачать заново

---

## 📊 КЛЮЧЕВЫЕ МЕТРИКИ

### Progress:
- Items: X/Y (Z%)
- Velocity: N items/chat
- ETA: M chats remaining

### Quality Score (0-100):
- Completeness: %
- Consistency: %
- Code Quality: %
- Documentation: %

### Token Efficiency:
- Used: X/200k
- Avg per item: Y tokens
- Remaining capacity: Z items

---

## 🔗 ИНТЕГРАЦИИ

| Платформа | Для чего |
|-----------|----------|
| **Git** | Версионирование checkpoint |
| **Notion** | База знаний и документация |
| **Trello** | Kanban boards для items |
| **Jira** | Project management |
| **Slack** | Уведомления о прогрессе |

---

## 💡 BEST PRACTICES

**DO:**
- ✅ Создавай checkpoint на 170-180k токенов
- ✅ Валидируй перед переходом в новый чат
- ✅ Используй BRIDGE для связи между фазами
- ✅ Отслеживай метрики качества
- ✅ Git commit после каждого чата

**DON'T:**
- ❌ Не жди 195k токенов (может не успеть)
- ❌ Не пропускай валидацию
- ❌ Не меняй методологию без обновления
- ❌ Не игнорируй падение качества
- ❌ Не забывай сохранять локально

---

## 📖 РАЗДЕЛЫ В ПОЛНОЙ ДОКУМЕНТАЦИИ

1. Быстрый старт (5 мин)
2. Полный Workflow (3 режима)
3. Автоматизация (5 скриптов)
4. Типы проектов (8 шаблонов)
5. Валидация (50+ проверок)
6. Интеграции (6 платформ)
7. Метрики (3 dashboard)
8. Troubleshooting (50+ сценариев)
9. Reference (guides, FAQ)

**Полная документация:** SKILL_PRO_v2_Migration_Assistant.md (1,152 строки)

---

## 🎯 КОГДА ИСПОЛЬЗОВАТЬ ЧТО

| Ситуация | Используй |
|----------|-----------|
| Первый раз | Базовый режим + v1.0 skill |
| 3-10 чатов | Авто режим + PRO |
| 10+ чатов | Enterprise + Python |
| Команда | Enterprise + Git + Notion |
| Compliance | Enterprise + audit trail |

---

## ⚙️ REQUIREMENTS

**Минимум:**
- Claude.ai аккаунт
- Текстовый редактор

**Для Python:**
- Python 3.7+
- Git (для --git-auto)

**Для интеграций:**
- API keys соответствующих сервисов

---

## 📞 ПОДДЕРЖКА

**Документация:**
- SKILL_PRO_v2_Migration_Assistant.md — Полная (1,152 строки)
- README_PRO_v2.md — Инструкция
- PRO_Quick_Reference.md — Эта шпаргалка

**Помощь:**
- Раздел Troubleshooting (50+ сценариев)
- Загрузи SKILL PRO в чат и спроси
- Примеры использования в документации

---

**Версия:** 2.0.0 PRO  
**Дата:** 2024-01-27  
**Страниц:** 2  
**Формат:** Quick Reference Cheat Sheet

**Храните эту шпаргалку под рукой! 📌**
