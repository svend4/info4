# ⚡ QUICK REFERENCE: СОЗДАНИЕ SKILLS

**Шпаргалка с командами для быстрого создания**

---

## 🚀 БЫСТРЫЙ СТАРТ (5 МИНУТ)

```
Скажи Claude:

"Создай skill для [задача]:
1. Структура папки
2. SKILL.md с YAML и инструкциями
3. Упакуй в .skill
4. Дай ссылку на скачивание"

Claude сделает всё автоматически! ✅
```

---

## 📋 КОМАНДЫ BASH

### Создание структуры:

```bash
# Создай папку и файл
mkdir my-skill
cd my-skill
touch SKILL.md
```

### Создание SKILL.md:

```bash
cat > SKILL.md << 'EOF'
---
name: my-skill
description: "Описание skill"
---

# My Skill

## Когда использовать

[Trigger условия]

## Инструкции

[Что делать]

## Примеры

[Примеры]
EOF
```

### Упаковка (СПОСОБ 1 - ЛУЧШИЙ):

```bash
python3 /mnt/skills/examples/skill-creator/scripts/package_skill.py \
  /home/claude/my-skill \
  /mnt/user-data/outputs
```

### Упаковка (СПОСОБ 2 - ВРУЧНУЮ):

```bash
cd /home/claude
zip -r /mnt/user-data/outputs/my-skill.skill my-skill/
```

### Проверка:

```bash
# Размер
ls -lh /mnt/user-data/outputs/my-skill.skill

# Структура
unzip -l /mnt/user-data/outputs/my-skill.skill

# YAML
head -10 /home/claude/my-skill/SKILL.md
```

---

## 📝 YAML FRONTMATTER

### Минимальный (обязательно):

```yaml
---
name: my-skill-name
description: "Краткое описание"
---
```

### С кавычками (если есть спецсимволы):

```yaml
---
name: my-api-skill
description: "Помогает создавать API документацию: endpoints, schemas, examples"
---
```

### Multiline:

```yaml
---
name: my-skill
description: |
  Длинное описание
  на несколько строк
  работает так
---
```

---

## 🎯 СТРУКТУРА SKILL.MD

### Minimal (50-100 строк):

```markdown
---
name: my-skill
description: "Описание"
---

# My Skill

## Когда использовать
[Trigger условия]

## Инструкции
[Что делать]

## Пример
[Один пример]
```

### Standard (150-250 строк):

```markdown
---
name: my-skill
description: "Описание"
---

# My Skill

## Когда использовать
[Trigger условия]

## Основная задача
[Цель]

## Пошаговый процесс
1. Шаг 1
2. Шаг 2

## Примеры
### Пример 1
[Код]

### Пример 2
[Код]

## Checklist
- [ ] Пункт 1
- [ ] Пункт 2

## Output
[Результат]
```

### Extended (500-1000 строк):

```markdown
---
name: my-skill
description: "Описание"
---

# My Skill

## Table of Contents
[Ссылки на разделы]

## Когда использовать
[Подробно]

## Детальные инструкции
[Фазы]

## Примеры (5-10)
[Детальные примеры]

## Best Practices
[✅ DO, ❌ DON'T]

## Troubleshooting
[Проблемы и решения]

## Advanced Features
[Дополнительно]

## Интеграция
[С другими skills]

## ROI & Metrics
[Цифры]

## Appendix
[Справочники]
```

---

## 💬 ЧТО ГОВОРИТЬ CLAUDE

### Создание простого skill:

```
"Создай skill для [задача].
SKILL.md должен содержать:
- YAML frontmatter
- Trigger условия
- Инструкции
- 2 примера
Упакуй в .skill и дай ссылку"
```

### Создание 2 версий:

```
"Создай 2 версии skill для [задача]:

1. compact - 200 строк, essential only
2. extended - 700 строк, полная документация

Упакуй обе в .skill и дай ссылки"
```

### Проверка YAML:

```
"Проверь что YAML в моём SKILL.md валидный"
```

### Исправление ошибок:

```
"В моём .skill файле ошибка:
[описание проблемы]

Исправь и пересоздай файл"
```

---

## 🔍 ПРОВЕРКА ПЕРЕД УСТАНОВКОЙ

```bash
# 1. Файл существует
ls -l /mnt/user-data/outputs/my-skill.skill

# 2. Это ZIP
file /mnt/user-data/outputs/my-skill.skill

# 3. Структура правильная
unzip -l /mnt/user-data/outputs/my-skill.skill
# Ожидается: my-skill/SKILL.md

# 4. YAML правильный
head -10 SKILL.md
```

---

## ⚠️ ЧАСТЫЕ ОШИБКИ

### ❌ ОШИБКА 1: Нет папки в архиве

```
Неправильно:
my-skill.skill
└── SKILL.md  ❌

Правильно:
my-skill.skill
└── my-skill/
    └── SKILL.md  ✅
```

**Решение:**

```bash
# Всегда упаковывай из родительской директории
cd /home/claude
zip -r my-skill.skill my-skill/
```

### ❌ ОШИБКА 2: YAML не валидный

```yaml
Неправильно:
description: Описание: с колоном  ❌

Правильно:
description: "Описание: с колоном"  ✅
```

**Решение:**

```yaml
# Добавь кавычки если есть:
# - Колоны (:)
# - Запятые (,)
# - Спецсимволы
```

### ❌ ОШИБКА 3: Расширение .zip вместо .skill

```
Неправильно: my-skill.zip  ❌
Правильно: my-skill.skill  ✅
```

**Решение:**

```bash
mv my-skill.zip my-skill.skill
```

---

## 📊 РАЗМЕРЫ ФАЙЛОВ

### Ориентиры:

```
Minimal skill:
- SKILL.md: 50-100 строк
- .skill file: 1-2 KB

Standard skill:
- SKILL.md: 150-250 строк
- .skill file: 2-4 KB

Extended skill:
- SKILL.md: 500-1000 строк
- .skill file: 6-12 KB

With references:
- SKILL.md: 200+ строк
- references/: 3-5 файлов
- .skill file: 8-20 KB
```

---

## 🎓 ШАБЛОНЫ ДЛЯ КОПИРОВАНИЯ

### Шаблон 1: API Documentation Skill

```yaml
---
name: api-docs-skill
description: "Создаёт API документацию по стандарту OpenAPI 3.0"
---

# API Documentation Skill

## Когда использовать

Когда пользователь:
- Просит создать API docs
- Упоминает REST API, endpoints
- Работает над API проектом

## Инструкции

1. Собери информацию об endpoints
2. Создай OpenAPI структуру
3. Добавь schemas
4. Добавь примеры

## Пример

[OpenAPI YAML пример]
```

### Шаблон 2: Code Review Skill

```yaml
---
name: code-review-skill  
description: "Проверяет код на соответствие best practices"
---

# Code Review Skill

## Когда использовать

Когда пользователь:
- Просит проверить код
- Спрашивает про code review
- Загружает код для проверки

## Критерии проверки

1. Style guide compliance
2. Security issues
3. Performance
4. Best practices
5. Documentation

## Output

Список findings с priority и recommendations
```

### Шаблон 3: README Creator Skill

```yaml
---
name: readme-creator-skill
description: "Создаёт профессиональные README для GitHub"
---

# README Creator Skill

## Когда использовать

Когда пользователь:
- Просит создать README
- Упоминает GitHub проект
- Нужна документация проекта

## Структура README

1. Title & Description
2. Installation
3. Usage
4. Features
5. Contributing
6. License

## Примеры

[3 примера разных стилей]
```

---

## 🔗 ИНТЕГРАЦИЯ С ДРУГИМИ SKILLS

### Как упомянуть другие skills:

```markdown
## Работа с другими skills

### Checkpoint Management
**Команда:** "Создай checkpoint"
**Когда:** После создания документации

### Code Review
**Команда:** "Проверь код"
**Когда:** Для проверки примеров

## Пример workflow

1. Создай документацию (этот skill)
2. Проверь примеры (code-review-skill)
3. Создай checkpoint (checkpoint-skill)
```

---

## ⚡ ULTRA QUICK COMMANDS

### One-liner создание minimal skill:

```bash
mkdir my-skill && cd my-skill && \
echo -e "---\nname: my-skill\ndescription: \"Описание\"\n---\n\n# My Skill\n\n[Content]" > SKILL.md && \
cd .. && zip -r my-skill.skill my-skill/
```

### One-liner проверка:

```bash
unzip -l my-skill.skill && head -5 my-skill/SKILL.md
```

---

## 📱 MOBILE-FRIENDLY КОМАНДЫ

### Создание через Claude:

```
1. "Создай skill структуру"
2. "Напиши SKILL.md"
3. "Упакуй в .skill"
4. "Дай ссылку"

Всё делается в чате! 📱
```

---

## 🎯 CHECKLIST

```
Перед упаковкой:
□ SKILL.md создан
□ YAML frontmatter есть
□ YAML валидный
□ Trigger условия чёткие
□ Примеры добавлены

Упаковка:
□ Используй package_skill.py (лучший способ)
□ Или ZIP из родительской директории
□ Проверь структуру архива
□ Расширение .skill (не .zip)

После упаковки:
□ Файл > 0 байт
□ unzip -l показывает my-skill/SKILL.md
□ Готов к скачиванию
□ Готов к установке
```

---

## 🎉 ИТОГО

### За 5 минут можешь создать:

```
✅ Структуру skill
✅ SKILL.md с контентом
✅ .skill файл
✅ Готовый к установке skill

Всё прямо в чате с Claude! 🚀
```

### Следующие шаги:

```
1. Скачай .skill файл
2. Settings → Skills в claude.ai
3. Upload Skill
4. Протестируй!
```

---

**Используй эту шпаргалку для быстрого создания skills!** ⚡

*От идеи до .skill файла за 5 минут!*
