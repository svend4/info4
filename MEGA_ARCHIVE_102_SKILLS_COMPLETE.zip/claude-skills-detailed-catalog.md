# Детальный каталог Claude Skills: от простого к сложному

## УРОВЕНЬ 1 — БАЗОВЫЕ SKILLS (повседневные задачи)

### КАТЕГОРИЯ 1.1: ФАЙЛОВЫЕ ОПЕРАЦИИ

---

## Skill #1: Smart File Organizer
**Уровень сложности:** 🟢 Базовый  
**Приоритет реализации:** 🔴 Высокий  
**Категория:** Файловые операции

### Описание
Интеллектуальная автоматизация организации файлов с пониманием контекста и содержимого. В отличие от простых правил сортировки (по расширению, дате), понимает смысл содержимого файлов и организует их семантически.

### Проблема которую решает
- Папка Downloads превращается в свалку (сотни файлов)
- Ручная сортировка занимает 10-15 минут ежедневно
- Трудно найти нужный файл среди хаоса
- Непонятно как организовать проектные документы

### Существующие решения и их ограничения

**Windows:**
- Вручную перетаскивание файлов
- Правила: "все .pdf в папку Documents" — примитивно

**AutoHotkey/PowerShell скрипты:**
```powershell
# Пример существующего решения
Get-ChildItem -Path "C:\Downloads" -Filter "*.pdf" | 
  Move-Item -Destination "C:\Documents"
```
❌ Проблема: организует только по расширению, не понимает контекст

**Hazel (Mac, $42):**
- Правила на основе имени/типа файла
- Может читать метаданные
❌ Проблема: не понимает содержимое, требует ручной настройки правил

**File Juggler (Windows, €29.95):**
- Автоматизация по паттернам
❌ Проблема: rigid rules, нет AI-понимания

### Как Claude улучшает это

**Семантическая организация:**
```
Пользователь: "Организуй мою папку Downloads"

Claude:
1. Сканирует все файлы
2. Анализирует содержимое:
   - "contract_final.pdf" → читает внутри, находит название компании "Acme Corp"
   - "IMG_2453.jpg" → видит EXIF данные "Свадьба, 2024-06-15"
   - "presentation.pptx" → читает слайды, понимает "Q3 Sales Report"
3. Создает осмысленную структуру:
   Documents/
     Contracts/
       Acme_Corp/
         contract_final.pdf
     Photos/
       2024/
         06_Свадьба/
           IMG_2453.jpg
     Work/
       Sales_Reports/
         Q3_2024/
           presentation.pptx
```

**Естественный язык для правил:**
```
Вместо: IF filename contains "invoice" AND extension = .pdf THEN move to Invoices
Используем: "Все счета и инвойсы складывай в папку Финансы/Счета по годам"
```

### Конкретные Use Cases

**Use Case 1: Фотограф организует съемки**
```
Ситуация: 5000 фотографий с разных мероприятий за месяц

Команда: "Разложи все фото по событиям, используя EXIF данные и содержание"

Результат:
2024_Photography/
  01_Детский_праздник_Петровы/
  02_Корпоратив_TechCorp/
  03_Свадьба_Анна_и_Иван/
```

**Use Case 2: Разработчик очищает Downloads**
```
Ситуация: Куча скачанных библиотек, документаций, скриншотов

Команда: "Собери все связанное с Python в Dev/Python, 
          документации в Docs по темам, скриншоты в Screenshots"

Результат:
- Автоопределение: numpy.whl → Dev/Python/Libraries/
- README.md (если внутри про Django) → Docs/Django/
- screenshot_error.png → Screenshots/Bugs/
```

**Use Case 3: Офисный работник**
```
Ситуация: Документы, таблицы, презентации смешаны

Команда: "Раздели по проектам, используя содержимое файлов"

Анализ:
- proposal_v3.docx (внутри "Project Phoenix") → Projects/Phoenix/
- budget.xlsx (в ячейках "Phoenix Budget Q3") → Projects/Phoenix/Finance/
```

### Технические требования

**MCP серверы:**
- `mcp-filesystem` — чтение/запись файлов
- `mcp-document-readers` — чтение docx, pdf, xlsx

**Python библиотеки:**
```python
# Для чтения метаданных
from PIL import Image
from PIL.ExifTags import TAGS
import PyPDF2
from docx import Document

# Для embeddings (семантический поиск)
from sentence_transformers import SentenceTransformer
```

**Алгоритм работы:**
```python
def organize_files(directory, instruction):
    # 1. Сканируем все файлы
    files = scan_directory(directory)
    
    # 2. Извлекаем метаданные и содержимое
    for file in files:
        metadata = extract_metadata(file)
        content = extract_content(file)
        
        # 3. Claude анализирует и определяет категорию
        category = claude_categorize(file, metadata, content, instruction)
        
        # 4. Создаем структуру и перемещаем
        create_category_folder(category)
        move_file(file, category)
```

### Пример реализации workflow

```markdown
1. Пользователь: "Организуй мою папку Downloads умно"

2. Skill активируется → читает SKILL.md

3. Выполнение:
   a) Сканирует Downloads/
   b) Для каждого файла:
      - Извлекает метаданные (EXIF, автор, дата)
      - Читает содержимое (первые параграфы документов)
      - Создает summary: "Это контракт с компанией X"
   c) Группирует по категориям
   d) Предлагает структуру пользователю:
      
      "Я нашел:
      - 15 финансовых документов
      - 23 фотографии с 3 событий
      - 7 рабочих документов по проекту Alpha
      
      Предлагаю структуру:
      Documents/Finance/
      Photos/2024/
      Work/Project_Alpha/
      
      Продолжить?"
   
   e) После подтверждения — перемещает файлы
   f) Создает отчет: "Организовано 45 файлов в 3 категории"
```

### Расширенные возможности

**Уровень 2 — Умные правила:**
```
"В будущем все PDF со словом 'invoice' складывай сразу в Finance/Invoices/[год]/"
```
Skill запоминает это как persistent rule

**Уровень 3 — Предиктивная организация:**
```
Анализирует паттерны:
"Вы обычно все файлы от john@company.com кладете в Projects/ClientX
Сделать это автоматически?"
```

### Метрики успеха
- Время на организацию: с 15 мин/день → 0 минут
- Точность категоризации: >90% (с human feedback)
- Удовлетворенность: users должны легко находить файлы

---

## Skill #2: Batch File Renamer
**Уровень сложности:** 🟢 Базовый  
**Приоритет реализации:** 🟡 Средний  
**Категория:** Файловые операции

### Описание
Массовое переименование файлов с использованием естественного языка вместо сложных регулярных выражений или GUI-утилит.

### Проблема которую решает
- Фотографии с камеры: "IMG_5234.jpg, IMG_5235.jpg" → нужны понятные имена
- Скриншоты: "Screenshot 2024-01-27 14-23-45.png" → слишком длинные
- Скачанные файлы: "document (1).pdf, document (2).pdf" → нужна структура

### Существующие решения и их ограничения

**Bulk Rename Utility (Windows):**
![Сложный GUI с десятками опций]
❌ Проблема: Нужно понимать паттерны замены, regex, счетчики

**PowerToys PowerRename:**
```
Find: Screenshot 
Replace: Bug_
Add: _[date]
```
❌ Проблема: Каждое действие — отдельная настройка

**Командная строка (Linux/Mac):**
```bash
for file in *.jpg; do
  mv "$file" "${file%.jpg}_vacation.jpg"
done
```
❌ Проблема: Нужны навыки bash scripting

### Как Claude улучшает это

**Естественный язык:**
```
Пользователь: "Переименуй все скриншоты: убери дату, добавь 'bug_' 
              в начало и номер по порядку"

Claude:
Screenshot 2024-01-27 14-23-45.png → bug_001.png
Screenshot 2024-01-27 15-10-23.png → bug_002.png
Screenshot 2024-01-28 09-05-11.png → bug_003.png
```

**Умное понимание контекста:**
```
Пользователь: "Переименуй фотографии с отпуска, добавив место и дату"

Claude анализирует EXIF:
IMG_5234.jpg (GPS: Париж, Date: 2024-06-15) → Paris_2024-06-15_001.jpg
IMG_5235.jpg (GPS: Париж, Date: 2024-06-15) → Paris_2024-06-15_002.jpg
```

### Конкретные Use Cases

**Use Case 1: Фотограф после съемки**
```
Ситуация: 500 фотографий DSC_0001.jpg ... DSC_0500.jpg

Команда: "Переименуй в формат: НазваниеСъемки_Дата_Номер"

Input: DSC_0001.jpg
Output: Wedding_Anna_Ivan_2024-06-15_001.jpg
```

**Use Case 2: Разработчик чистит Downloads**
```
Ситуация: 
document (1).pdf
document (2).pdf  
presentation - final - FINAL - use this.pptx

Команда: "Убери скобки, дубликаты слов, сделай snake_case"

Output:
document_1.pdf
document_2.pdf
presentation_final.pptx
```

**Use Case 3: Офисный работник**
```
Ситуация: Версии одного документа

Proposal_v1.docx
Proposal_v2_comments.docx
Proposal_FINAL.docx
Proposal_FINAL_2.docx

Команда: "Приведи к нормальной версионности: proposal_v1, v2, v3..."

Output:
proposal_v1.docx
proposal_v2.docx
proposal_v3.docx
proposal_v4.docx
```

### Технические требования

**MCP серверы:**
- `mcp-filesystem` — переименование файлов

**Python пример:**
```python
def batch_rename(directory, instruction):
    files = list_files(directory)
    
    # Claude генерирует новые имена
    new_names = claude_generate_names(files, instruction)
    
    # Preview для подтверждения
    preview = create_preview(files, new_names)
    
    if user_confirms(preview):
        for old, new in zip(files, new_names):
            os.rename(old, new)
```

### Особенности реализации

**1. Превью перед выполнением:**
```
Планируемые изменения:

IMG_5234.jpg → Paris_2024-06-15_001.jpg
IMG_5235.jpg → Paris_2024-06-15_002.jpg
...
(ещё 498 файлов)

Продолжить? (yes/no/show all)
```

**2. Обработка коллизий:**
```
Ошибка: Paris_2024-06-15_001.jpg уже существует

Варианты:
1. Перезаписать
2. Добавить суффикс (_1)
3. Пропустить файл
```

**3. Undo возможность:**
```
Skill сохраняет историю:
.rename_history.json:
{
  "session_id": "2024-01-27_15-30",
  "changes": [
    {"old": "IMG_5234.jpg", "new": "Paris_001.jpg"}
  ]
}

Команда: "Отмени последнее переименование"
```

### Расширенные возможности

**Извлечение даты из содержимого:**
```
Файл: report.docx
Внутри: "Quarterly Report Q3 2024"

Команда: "Переименуй файлы, добавив дату из содержимого"
Output: report_Q3_2024.docx
```

**Транслитерация:**
```
Input: Отчет за январь.docx
Команда: "Транслитерируй в английский, замени пробелы на _"
Output: otchet_za_yanvar.docx
```

---

## Skill #3: Duplicate Hunter
**Уровень сложности:** 🟡 Средний  
**Приоритет реализации:** 🟡 Средний  
**Категория:** Файловые операции

### Описание
Интеллектуальный поиск дубликатов с пониманием "похожести" — не только точных копий, но и файлов с разными именами, но идентичным или очень похожим содержимым.

### Проблема которую решает
- Диск забит дубликатами (фото скопированы несколько раз)
- Одни и те же документы под разными названиями
- Версии файлов без системы версионности
- Невозможно найти "оригинал" среди копий

### Существующие решения и их ограничения

**CCleaner Duplicate Finder:**
- Сравнивает по MD5 хешу
❌ Ограничение: Находит только ТОЧНЫЕ копии
❌ Пример: report_v1.docx и report_v2.docx (99% одинаковые) — не найдет

**Duplicate Cleaner Pro ($30):**
- Сравнение по имени, размеру, дате, хешу
- Может сравнивать изображения визуально
✅ Лучше, но:
❌ Не понимает смысл содержимого документов

**fdupes (Linux):**
```bash
fdupes -r /home/user/Documents
```
❌ Только точные побайтовые копии

### Как Claude улучшает это

**Семантический поиск дубликатов:**
```
Файл 1: "Company Strategy 2024.docx"
Файл 2: "Strategic Plan 2024 FINAL.docx"

Обычный инструмент: Разные файлы (разные имена/размеры)

Claude: 
1. Читает оба файла
2. Анализирует содержимое
3. Вывод: "96% идентичны, отличия только в форматировании титульной страницы"
4. Предлагает: "Удалить один? Или объединить в версионную историю?"
```

**Находит версии документов:**
```
budget_draft.xlsx
budget_v1.xlsx
budget_final.xlsx  
budget_FINAL_approved.xlsx

Claude: "Это 4 версии одного документа, прогрессия изменений:
        draft → v1 (добавлена строка Marketing)
        v1 → final (изменены формулы)
        final → approved (без изменений, только переименование)
        
        Рекомендация: Оставить budget_v1.xlsx и budget_FINAL_approved.xlsx,
                      остальные переместить в Archive/"
```

### Конкретные Use Cases

**Use Case 1: Очистка диска**
```
Ситуация: Диск заполнен на 95%, нужно освободить место

Команда: "Найди все дубликаты и покажи сколько места они занимают"

Claude сканирует и показывает:
Найдено дубликатов: 45 GB
Категории:
- Фотографии: 25 GB (3,500 точных копий)
- Видео: 15 GB (5 файлов в разных папках)
- Документы: 3 GB (120 файлов с вариациями названий)
- Архивы: 2 GB (старые бэкапы)

Что удалить?
```

**Use Case 2: Фотограф чистит библиотеку**
```
Ситуация: 50,000 фотографий, много дублей

Команда: "Найди дубликаты фото, включая отредактированные версии"

Claude:
1. Хеш-дубликаты: 2,500 точных копий → можно удалить
2. Визуальные дубли: 
   IMG_5234.jpg (оригинал)
   IMG_5234_edited.jpg (цветокоррекция)
   IMG_5234_cropped.jpg (обрезан)
   → Предлагает: "Оставить оригинал + лучшую отредактированную версию?"
```

**Use Case 3: Разработчик находит code duplication**
```
Ситуация: Проект с дублированным кодом

Команда: "Найди файлы с похожим кодом"

Claude анализирует:
utils/helpers.py (функция format_date)
src/formatters.py (функция format_date) 
→ 100% идентичная функция

components/Button.jsx
components/CustomButton.jsx
→ 95% идентичны, отличие в названиях пропсов

Рекомендация: "Рефакторинг: создать shared/utils.py"
```

### Технические требования

**Для точных дубликатов:**
```python
import hashlib

def find_exact_duplicates(directory):
    hashes = {}
    for file in walk_directory(directory):
        file_hash = hashlib.md5(file_content).hexdigest()
        if file_hash in hashes:
            # Дубликат найден
            duplicates.append((file, hashes[file_hash]))
        else:
            hashes[file_hash] = file
```

**Для семантических дубликатов (Claude):**
```python
from sentence_transformers import SentenceTransformer

def find_semantic_duplicates(documents):
    # Создаем embeddings для каждого документа
    embeddings = model.encode([doc.content for doc in documents])
    
    # Вычисляем cosine similarity
    similarities = cosine_similarity(embeddings)
    
    # Находим пары с similarity > 0.85
    for i, j in np.where(similarities > 0.85):
        if i != j:
            potential_duplicates.append((docs[i], docs[j], similarities[i,j]))
```

**MCP серверы:**
- `mcp-filesystem` — сканирование файлов
- `mcp-document-readers` — чтение содержимого

### Алгоритм работы

```
1. СКАНИРОВАНИЕ
   ├─ Рекурсивный обход директорий
   ├─ Вычисление хешей для быстрого сравнения
   └─ Извлечение метаданных (размер, дата, тип)

2. УРОВЕНЬ 1: Точные дубликаты (по MD5)
   └─ Быстро, можно удалять автоматически

3. УРОВЕНЬ 2: Визуальные дубли (для изображений)
   └─ perceptual hash (phash)

4. УРОВЕНЬ 3: Семантические дубли (Claude)
   ├─ Читаем содержимое
   ├─ Создаем embeddings
   ├─ Вычисляем similarity
   └─ Предлагаем пользователю решение

5. ДЕЙСТВИЯ
   ├─ Delete
   ├─ Move to Archive
   ├─ Keep newer/larger
   └─ Merge (для версионированных документов)
```

### Пример интерфейса

```
=== Duplicate Hunter Results ===

📊 СТАТИСТИКА:
Scanned: 15,234 files (45.2 GB)
Found:
 • 234 exact duplicates (2.1 GB) 
 • 45 similar documents (850 MB)
 • 12 image variants (320 MB)

🔴 CRITICAL: Exact duplicates (auto-safe to delete)
───────────────────────────────────────────────
1. Photo_vacation.jpg
   → Also in: /Backup/2024/, /Google Drive/Photos/
   Copies: 3 | Size: 4.5 MB each | Total waste: 9 MB
   
2. presentation.pptx
   → Also in: /Desktop/, /Downloads/, /Email Attachments/
   Copies: 3 | Size: 12 MB each | Total waste: 24 MB

Actions:
[K]eep newest in /Photos/, delete others
[M]anual selection
[S]kip

🟡 REVIEW NEEDED: Similar documents (may be versions)
────────────────────────────────────────────────────
1. proposal_v1.docx (125 KB) vs proposal_final.docx (128 KB)
   Similarity: 94% | Main diff: Added conclusion section
   
   [K]eep both | Keep [N]ewest | [V]iew diff | [D]elete older

Commands: 
 • "Delete all exact duplicates, keep newest" 
 • "Show me all duplicates of presentation.pptx"
 • "Move all duplicates to /Archive/Duplicates/"
```

### Расширенные возможности

**Автоматическая дедупликация при копировании:**
```
Пользователь копирует файл в папку
Claude: "Этот файл уже есть в папке (MD5 совпадает). 
        Перезаписать / Переименовать / Отмена?"
```

**Поиск вариаций файлов:**
```
Command: "Найди все версии файла contract.pdf"

Result:
contract.pdf               (original, 2024-01-15)
contract_v2.pdf           (updated, 2024-01-20)
contract_reviewed.pdf     (98% similar, 2024-01-22)
contract_FINAL.pdf        (99% similar, 2024-01-25)
contract_signed.pdf       (signature added, 2024-01-27)

Timeline visualization showing evolution
```

---

## Skill #4: Archive Manager
**Уровень сложности:** 🟢 Базовый  
**Приоритет реализации:** 🟢 Низкий  
**Категория:** Файловые операции

### Описание
Универсальная работа с архивами — создание, распаковка, конвертация между форматами с умным выбором параметров сжатия.

### Проблема которую решает
- Нужно быстро заархивировать/разархивировать файлы
- Разные форматы: .zip, .rar, .7z, .tar.gz
- Непонятно какой уровень сжатия выбрать
- Массовая обработка архивов

### Существующие решения

**7-Zip (Windows, бесплатный):**
- GUI для архивации
- Командная строка: `7z a archive.7z files/`
✅ Хороший инструмент
❌ Нужно помнить команды и параметры

**WinRAR ($29):**
- Popular GUI tool
❌ Платный
❌ Устаревающий UI

**tar/gzip (Linux/Mac):**
```bash
tar -czf archive.tar.gz directory/
tar -xzf archive.tar.gz
```
❌ Нужно помнить флаги (-c, -x, -z, -v...)

### Как Claude улучшает это

**Естественный язык:**
```
Вместо: tar -czf project_backup.tar.gz --exclude=node_modules project/

Команда: "Заархивируй папку project, исключи node_modules, 
         максимальное сжатие"

Claude:
1. Определяет оптимальный формат (.7z для max compression)
2. Автоматически исключает ненужное (node_modules, .git, __pycache__)
3. Показывает прогресс
4. Выводит статистику: "Сжато 1.2 GB → 245 MB (80% reduction)"
```

**Умный выбор формата:**
```
Пользователь: "Заархивируй эти файлы для отправки клиенту"

Claude анализирует:
- Содержимое: документы + изображения
- Целевая платформа: Windows (клиент)
- Приоритет: совместимость > сжатие

Выбирает: .zip (100% совместимость с Windows)
Вместо: .7z (лучше сжатие, но нужна установка 7-Zip)
```

### Конкретные Use Cases

**Use Case 1: Архивация проекта**
```
Команда: "Создай бэкап проекта myapp для хранения"

Claude:
1. Сканирует структуру проекта
2. Автоматически исключает:
   - node_modules/ (можно восстановить через npm install)
   - .git/ (отдельный бэкап)
   - dist/, build/ (результаты сборки)
   - *.log, *.tmp
3. Создает: myapp_backup_2024-01-27.7z (максимальное сжатие)
4. Добавляет README внутри с датой и версией
```

**Use Case 2: Массовая распаковка**
```
Ситуация: Папка с 50 архивами разных форматов

Команда: "Распакуй все архивы, каждый в свою папку"

Claude:
archive1.zip → archive1/
archive2.rar → archive2/
archive3.tar.gz → archive3/

Обрабатывает все форматы автоматически
```

**Use Case 3: Конвертация форматов**
```
Ситуация: Старые .rar архивы, нужны .zip для совместимости

Команда: "Конвертируй все .rar в .zip"

Claude:
old_archive.rar → распаковывает → упаковывает в old_archive.zip
(сохраняет структуру, права файлов, timestamps)
```

### Технические требования

**Python библиотеки:**
```python
import zipfile
import tarfile
import py7zr  # для .7z
import rarfile  # для .rar

def smart_archive(source, dest, format='auto'):
    if format == 'auto':
        format = choose_optimal_format(source)
    
    if format == 'zip':
        with zipfile.ZipFile(dest, 'w', zipfile.ZIP_DEFLATED) as zf:
            add_to_archive(zf, source)
    elif format == '7z':
        with py7zr.SevenZipFile(dest, 'w') as archive:
            archive.writeall(source)
```

**MCP серверы:**
- `mcp-filesystem` — доступ к файлам
- Bash integration для системных утилит

### Особенности реализации

**1. Автоисключение паттернов:**
```python
DEFAULT_EXCLUDE_PATTERNS = [
    'node_modules/**',
    '__pycache__/**',
    '*.pyc',
    '.git/**',
    '.DS_Store',
    'Thumbs.db',
    '*.tmp',
    '*.log'
]

# Пользователь может добавить свои
custom_exclude = [
    'data/raw/**',  # большие сырые данные
    '*.psd',        # исходники Photoshop
]
```

**2. Умное сжатие:**
```python
def choose_compression_level(file_types):
    # Анализируем типы файлов
    if most_files_are(['jpg', 'png', 'mp4', 'zip']):
        # Уже сжаты, не стоит тратить время
        return 'store'  # без дополнительного сжатия
    
    elif most_files_are(['txt', 'log', 'json', 'xml']):
        # Текстовые файлы хорошо сжимаются
        return 'maximum'
    
    else:
        return 'balanced'  # компромисс скорость/размер
```

**3. Preview и подтверждение:**
```
Планируется создать: project_backup.7z

Включено:
  src/ (1,234 files, 45 MB)
  docs/ (56 files, 12 MB)
  config/ (8 files, 125 KB)

Исключено:
  node_modules/ (15,234 files, 450 MB)
  .git/ (история, 89 MB)
  
Estimated compressed size: ~15 MB (74% reduction)
Estimated time: ~30 seconds

Proceed? [Y/n]
```

---

## Skill #5: Smart Backup Assistant
**Уровень сложности:** 🟡 Средний  
**Приоритет реализации:** 🔴 Высокий  
**Категория:** Файловые операции

### Описание
Интеллектуальная система резервного копирования, которая понимает важность файлов, частоту изменений и автоматически создает оптимальную стратегию бэкапа.

### Проблема которую решает
- Потеря важных данных из-за отсутствия бэкапов
- Бэкапы всего подряд (много места + долго)
- Непонятно как часто делать бэкапы
- Забывают делать бэкапы регулярно

### Существующие решения

**Time Machine (Mac):**
- Автоматические бэкапы каждый час
❌ Бэкапит всё подряд (много места)
❌ Нет выборочной стратегии

**Robocopy (Windows):**
```bash
robocopy C:\Source D:\Backup /MIR /R:3 /W:10
```
✅ Мощный инструмент
❌ Сложный синтаксис
❌ Нужно настраивать расписание вручную

**rsync (Linux/Mac):**
```bash
rsync -avz --delete /source/ /backup/
```
✅ Эффективный incremental backup
❌ Нужны знания Linux

**Cloud backup (Backblaze, Carbonite):**
✅ Автоматические, надежные
❌ Дорогие ($70-150/year)
❌ Медленные (зависит от интернета)

### Как Claude улучшает это

**Адаптивная стратегия:**
```
Claude анализирует:
1. Какие файлы критичны? (документы > фото > временные файлы)
2. Как часто они меняются? (код каждый час vs архив раз в год)
3. Сколько доступно места для бэкапа?
4. Есть ли облачное хранилище?

Создает план:
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
BACKUP STRATEGY для пользователя Max
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

📁 Documents/ (45 GB, изменения ежедневно)
   → Локальный бэкап: каждые 6 часов
   → Cloud sync: Google Drive (real-time)
   → История версий: 30 дней

💻 Code/ (12 GB, изменения ежечасно)
   → Git: continuous (уже есть)
   → Локальный бэкап: ежедневно в конце дня
   → Cloud: еженедельный snapshot на S3

📸 Photos/ (250 GB, редко меняется)
   → Локальный бэкап: еженедельно
   → Cloud: ежемесячный архив (Google Photos)

🎬 Videos/ (1.2 TB, редко меняется)
   → Внешний HDD: ежемесячно
   → Cloud: критичные ролики only

🗑️ Downloads/, Temp/ 
   → Без бэкапа (можно заново скачать)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Общее пространство: 307 GB бэкапов
Время выполнения: ~2 часа/неделя
```

**Интеллектуальное планирование:**
```
Пользователь: "Настрой мне бэкапы"

Claude:
"Я заметил:
- Вы активно работаете с проектом /Code/myapp (git commits ежедневно)
- Папка /Documents/ содержит важные финансовые файлы
- У вас есть Google Drive (15 GB) и внешний HDD (2 TB)

Предлагаю:
1. Code/myapp → GitHub (уже делаете) + локальная копия на HDD
2. Documents/ → Google Drive синхронизация + HDD ежедневно
3. Photos/ → HDD еженедельно

Это даст вам 3-2-1 backup правило:
 • 3 копии данных
 • 2 разных носителя
 • 1 off-site (Google Drive)

Подтвердить?"
```

### Конкретные Use Cases

**Use Case 1: Разработчик**
```
Критичные данные:
- Текущие проекты (код)
- Клиентские проекты
- Конфигурации IDE
- SSH ключи, credentials

Стратегия:
Code/ → Git (continuous) + Time Machine style local backup
.ssh/, .aws/ → Encrypted backup в облаке ежедневно
IDE settings/ → Sync через Dropbox

Если диск умирает:
1. Git clone проекты (3 минуты)
2. Restore .ssh и credentials (30 секунд)
3. Import IDE settings (1 минута)
→ Рабочая среда восстановлена за 5 минут
```

**Use Case 2: Дизайнер**
```
Критичные данные:
- PSD файлы проектов (большие, часто меняются)
- Finalized exports (PNG, SVG)
- Fonts, assets

Стратегия:
Active_Projects/ → Incremental backup каждые 2 часа (только изменения)
Completed_Projects/ → Еженедельный архив на HDD
Assets/ → Cloud sync (Dropbox)

Если диск умирает:
1. Restore текущие проекты с HDD (2 часа назад) → потеря max 2 часа работы
2. Finalized files с Dropbox → актуальные
```

**Use Case 3: Фотограф**
```
Данные:
- RAW files (огромные, 50+ MB каждый)
- Edited JPEG (маленькие)
- Проектные файлы Lightroom

Стратегия:
RAW/ → Immediate copy на 2 HDD (RAID-like)
Edited/ → Cloud backup (Google Photos)
Lightroom catalogs/ → Ежедневный бэкап

Правило 3-2-1:
- 3 копии: Working HDD + Backup HDD + Cloud
- 2 носителя: HDD + Cloud
- 1 off-site: Cloud
```

### Технические требования

**MCP серверы:**
- `mcp-filesystem` — мониторинг изменений
- `mcp-cloud-storage` — Google Drive, Dropbox, S3

**Python для мониторинга:**
```python
from watchdog.observers import Observer
from watchdog.events import FileSystemEventHandler

class SmartBackupHandler(FileSystemEventHandler):
    def on_modified(self, event):
        file_path = event.src_path
        
        # Определяем важность файла
        priority = assess_file_importance(file_path)
        
        if priority == 'CRITICAL':
            # Немедленный бэкап
            backup_immediately(file_path)
        elif priority == 'HIGH':
            # Добавить в очередь ближайшего бэкапа
            queue_for_next_backup(file_path)
```

**Оценка важности файлов:**
```python
def assess_file_importance(file_path):
    # 1. Расширение
    critical_extensions = ['.psd', '.ai', '.docx', '.xlsx']
    
    # 2. Размер (очень большие файлы = долго восстановить)
    size = get_file_size(file_path)
    
    # 3. Частота изменений
    modification_frequency = analyze_git_history(file_path)
    
    # 4. Содержимое (Claude анализ)
    if contains_financial_data(file_path):
        return 'CRITICAL'
    
    # 5. Позиция в проекте
    if file_path.startswith('/Code/Active_Projects/'):
        return 'HIGH'
    elif file_path.startswith('/Downloads/'):
        return 'LOW'
```

### Расширенные возможности

**1. Версионирование:**
```
Documents/
  contract.docx
  .backups/
    contract_2024-01-27_14-30.docx
    contract_2024-01-27_09-15.docx
    contract_2024-01-26_16-45.docx

Хранить версии:
- Последние 24 часа: каждое сохранение
- Последняя неделя: ежедневные версии
- Последний месяц: еженедельные
- Старше месяца: ежемесячные
```

**2. Smart deduplication:**
```
Photo_Library/
  2024/
    01/vacation/
      IMG_001.jpg (5 MB)
      IMG_002.jpg (5 MB)
      
Backup:
  Full backup: 10 MB
  Incremental: только новые фото
  Deduplication: если IMG_001.jpg идентичен в другой папке,
                 сохранить ссылку вместо копии
```

**3. Restore wizard:**
```
Пользователь: "Верни мне файл contract.docx какой был вчера вечером"

Claude:
"Нашел 3 версии contract.docx около вчерашнего вечера:

1. 2024-01-26 17:45 (234 KB) — последняя версия дня
2. 2024-01-26 15:30 (230 KB) — после правок от юриста
3. 2024-01-26 14:00 (228 KB) — начало работы

Какую восстановить? [1]"
```

---

### КАТЕГОРИЯ 1.2: ТЕКСТОВАЯ ОБРАБОТКА

## Skill #6: Universal Text Transformer
**Уровень сложности:** 🟢 Базовый  
**Приоритет реализации:** 🔴 Высокий  
**Категория:** Текстовая обработка

### Описание
Умное преобразование текста с пониманием контекста — регистр, форматирование, транслитерация, очистка — всё через естественный язык.

### Проблема которую решает
- Текст в НЕПРАВИЛЬНОМ РЕГИСТРЕ
- Нужно быстро изменить формат: camelCase → snake_case
- Транслитерация для URL: "Привет мир" → "privet-mir"
- Очистка: лишние пробелы, переносы строк, спецсимволы

### Существующие решения

**Online tools:**
- convertcase.net, titlecase.com
❌ Нужно копировать в браузер
❌ Одна операция за раз

**Text editors (VS Code, Sublime):**
- Transform to: UPPERCASE, lowercase, Title Case
✅ Быстро в редакторе
❌ Ограниченный набор трансформаций
❌ Нет понимания контекста

**TextExpander, PhraseExpress:**
- Автозамена abbreviations
✅ Удобно для частых фраз
❌ Нужно заранее настроить правила

**Командная строка:**
```bash
echo "hello world" | tr '[:lower:]' '[:upper:]'
# HELLO WORLD

echo "Hello World" | sed 's/ /-/g'
# Hello-World
```
❌ Нужно знать синтаксис tr, sed, awk

### Как Claude улучшает это

**Контекстное понимание:**
```
Текст: "ПРИВЕТ! это ТеКсТ для ПРИМЕРа."

Команда: "Приведи в нормальный вид для документа"

Claude понимает контекст "документ" означает:
- Первое слово с заглавной
- Остальное lowercase
- Правильная пунктуация

Результат: "Привет! Это текст для примера."
```

**VS примитивное "Title Case":**
```
Примитивный Title Case: "The Quick Brown Fox Jumps Over The Lazy Dog"
                        ↑   ↑     ↑     ↑   ↑     ↑    ↑   ↑    ↑
                        Все слова с большой буквы

Claude: "The Quick Brown Fox Jumps over the Lazy Dog"
        ↑   ↑     ↑     ↑   ↑              ↑    ↑
        Служебные слова (over, the) — lowercase
```

**Программирование:**
```
Текст: "user profile settings"

Команда: "Преобразуй для JavaScript"
Результат: "userProfileSettings" (camelCase)

Команда: "Преобразуй для Python"
Результат: "user_profile_settings" (snake_case)

Команда: "Преобразуй для константы"
Результат: "USER_PROFILE_SETTINGS" (SCREAMING_SNAKE_CASE)

Команда: "Преобразуй для CSS class"
Результат: "user-profile-settings" (kebab-case)
```

### Конкретные Use Cases

**Use Case 1: Исправление capslock текста**
```
Input (пользователь забыл выключить Caps Lock):
"пРИВЕТ! Я ХОТЕЛ НАПИСАТЬ НОРМАЛЬНО, НО У МЕНЯ КАПСЛОК БЫЛ ВКЛЮЧЕН."

Команда: "Исправь регистр"

Output:
"Привет! Я хотел написать нормально, но у меня капслок был включён."
```

**Use Case 2: Подготовка для URL**
```
Input: "Руководство по настройке WordPress"

Команда: "Преобразуй для URL (slug)"

Output: "rukovodstvo-po-nastroike-wordpress"

Автоматически:
- Транслитерация
- Lowercase
- Пробелы → дефисы
- Убраны спецсимволы
```

**Use Case 3: Программист переименовывает переменные**
```
Input (список переменных в snake_case):
user_name
email_address
phone_number
created_at

Команда: "Конвертируй в camelCase для JavaScript"

Output:
userName
emailAddress
phoneNumber
createdAt
```

**Use Case 4: SEO-специалист пишет заголовки**
```
Input: "как настроить рекламу в google ads"

Команда: "Сделай заголовок для SEO"

Claude понимает best practices:
Output: "Как настроить рекламу в Google Ads"

Учтено:
- Title Case для заголовка
- Правильное написание бренда "Google Ads"
- Грамматика сохранена
```

**Use Case 5: Очистка текста от мусора**
```
Input (скопировано из PDF):
"Это    текст   с    лишними    
пробелами и     
переносами
строк."

Команда: "Почисть текст"

Output:
"Это текст с лишними пробелами и переносами строк."
```

### Технические требования

**Базовый Python код:**
```python
def transform_text(text, instruction):
    """
    Claude анализирует instruction и применяет нужные преобразования
    """
    
    # Простые case transformations
    if "uppercase" in instruction.lower():
        return text.upper()
    
    if "lowercase" in instruction.lower():
        return text.lower()
    
    # Умные преобразования через Claude
    prompt = f"""
    Transform this text according to instruction.
    
    Text: {text}
    Instruction: {instruction}
    
    Return only transformed text, no explanations.
    """
    
    return claude_api(prompt)
```

**Транслитерация (для русского):**
```python
TRANSLIT_MAP = {
    'а': 'a', 'б': 'b', 'в': 'v', 'г': 'g', 'д': 'd',
    'е': 'e', 'ё': 'yo', 'ж': 'zh', 'з': 'z', 'и': 'i',
    'й': 'y', 'к': 'k', 'л': 'l', 'м': 'm', 'н': 'n',
    'о': 'o', 'п': 'p', 'р': 'r', 'с': 's', 'т': 't',
    'у': 'u', 'ф': 'f', 'х': 'h', 'ц': 'ts', 'ч': 'ch',
    'ш': 'sh', 'щ': 'sch', 'ъ': '', 'ы': 'y', 'ь': '',
    'э': 'e', 'ю': 'yu', 'я': 'ya'
}

def translit(text):
    result = []
    for char in text.lower():
        result.append(TRANSLIT_MAP.get(char, char))
    return ''.join(result)
```

**Case conversions:**
```python
def to_camel_case(text):
    # "user name" → "userName"
    words = text.replace('-', ' ').replace('_', ' ').split()
    return words[0].lower() + ''.join(w.capitalize() for w in words[1:])

def to_snake_case(text):
    # "userName" → "user_name"
    import re
    text = re.sub('(.)([A-Z][a-z]+)', r'\1_\2', text)
    text = re.sub('([a-z0-9])([A-Z])', r'\1_\2', text)
    return text.lower()

def to_kebab_case(text):
    # "userName" → "user-name"
    return to_snake_case(text).replace('_', '-')
```

### Пример интерфейса

```
Text Transformer
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Input text:
┌────────────────────────────────────┐
│ ПРИВЕТ это ТЕСТОВЫЙ текст          │
│ для   демонстрации    работы!      │
└────────────────────────────────────┘

Command: "Нормализуй для документа"

Preview:
┌────────────────────────────────────┐
│ Привет, это тестовый текст для     │
│ демонстрации работы!               │
└────────────────────────────────────┘

Applied transformations:
✓ Fixed capitalization
✓ Normalized whitespace
✓ Added punctuation

[Apply] [Cancel] [Try another command]

Quick actions:
• "Для URL-slug"
• "camelCase"
• "UPPERCASE"
• "Транслитерация"
```

### Расширенные возможности

**1. Batch processing:**
```
Input (файл с 100 строками):
user_first_name
user_last_name
user_email_address
...

Команда: "Конвертируй весь список в camelCase"

Output:
userFirstName
userLastName
userEmailAddress
...
```

**2. Smart quotes:**
```
Input: "Hello "world""

Команда: "Исправь кавычки"

Output: "Hello "world""
(прямые кавычки → типографские)
```

**3. Markdown formatting:**
```
Input: "заголовок\nЭто параграф текста.\nДругой параграф."

Команда: "Преобразуй в Markdown"

Output:
# Заголовок

Это параграф текста.

Другой параграф.
```

---

## Skill #7: Smart Clipboard Manager
**Уровень сложности:** 🟡 Средний  
**Приоритет реализации:** 🟡 Средний  
**Категория:** Текстовая обработка

### Описание
Интеллектуальный менеджер буфера обмена с историей, семантическим поиском и умной вставкой.

### Проблема которую решает
- Скопировал что-то важное → скопировал что-то ещё → первое потерялось
- Нужно найти текст, который копировал вчера
- Копируешь из разных мест, нужно собрать в один документ
- Нужно вставить разный текст в разных контекстах

### Существующие решения

**Clipboard в ОС:**
- Хранит только последний скопированный элемент
❌ История не сохраняется

**Ditto (Windows, бесплатный):**
![Список истории clipboard]
✅ История clipboard
✅ Поиск по тексту
❌ Только текстовый поиск (не семантический)
❌ Нет умной вставки

**CopyQ (Multi-platform, бесплатный):**
✅ История + табы для организации
✅ Скрипты для автоматизации
❌ Сложная настройка
❌ Не понимает контекст

**Paste (Mac, $15/year):**
✅ Красивый интерфейс
✅ iCloud sync
❌ Платный
❌ Только базовый поиск

### Как Claude улучшает это

**Семантический поиск:**
```
История clipboard (последние 100 копирований):
1. "john.doe@company.com"
2. "Meeting tomorrow at 3pm"
3. "https://github.com/user/repo"
4. "Don't forget to call the client"
...

Обычный поиск: "email"
→ Находит только элементы содержащие слово "email": 0 результатов

Claude search: "Найди тот email, который я копировал"
→ Понимает что ищем: "john.doe@company.com"

Claude search: "Найди про встречу"
→ Находит: "Meeting tomorrow at 3pm"
```

**Умная вставка (context-aware paste):**
```
Scenario: Пишешь email

Скопировал текст: "Встретимся завтра в 15:00"

Вставляешь в официальный email:
Claude: "We will meet tomorrow at 3:00 PM"
(автоматически переводит и делает формальным)

Вставляешь в Telegram другу:
Claude: "Встретимся завтра в 15:00"
(оставляет как есть, неформально)
```

### Конкретные Use Cases

**Use Case 1: Сбор информации из разных источников**
```
Задача: Написать отчет, информация разбросана

Действия:
1. Читаешь статью → копируешь ключевую цитату
2. Смотришь таблицу в Excel → копируешь данные
3. Находишь ссылку → копируешь URL
4. Смотришь email → копируешь контакт

Claude Clipboard собирает всё:
[1] "According to the research..." (статья)
[2] Q1: $2M, Q2: $2.5M, Q3: $3M (таблица)
[3] https://research.com/report-2024 (ссылка)
[4] contact@client.com (email)

Команда: "Вставь всё это в документ как отчет"

Claude:
- Форматирует цитату как blockquote
- Преобразует данные в таблицу
- Делает ссылку кликабельной
- Добавляет контакт в секцию "Contacts"
```

**Use Case 2: Программист копирует код**
```
История:
[1] def calculate_total(items): ... (Python function)
[2] SELECT * FROM users WHERE ... (SQL query)
[3] git commit -m "Fix bug in..." (bash command)

Поиск: "Та функция для расчёта"
→ Находит [1], показывает код с syntax highlighting

Вставка в разные редакторы:
- VS Code → вставляет как есть
- Google Docs → форматирует как code block
- Slack → оборачивает в ```python ... ```
```

**Use Case 3: Многоязычная работа**
```
Скопировал: "Добрый день! Хочу обсудить проект."

Вставляешь в email английскому коллеге:
Claude: "Good afternoon! I would like to discuss the project."
(автоперевод + формальный стиль)

Вставляешь в личный блокнот:
Claude: "Добрый день! Хочу обсудить проект."
(оригинал без изменений)
```

### Технические требования

**MCP серверы:**
- `mcp-clipboard` — мониторинг системного clipboard
- Local storage для истории

**Мониторинг clipboard:**
```python
import pyperclip
from watchdog.observers import Observer

class ClipboardMonitor:
    def __init__(self):
        self.history = []
        self.last_clipboard = ""
    
    def monitor(self):
        while True:
            current = pyperclip.paste()
            if current != self.last_clipboard:
                self.on_clipboard_change(current)
                self.last_clipboard = current
            time.sleep(0.5)
    
    def on_clipboard_change(self, content):
        entry = {
            'content': content,
            'timestamp': datetime.now(),
            'type': detect_type(content),  # text, image, code, url
            'source_app': get_active_app(),
            'embedding': create_embedding(content)  # для семантического поиска
        }
        self.history.append(entry)
        self.save_to_storage(entry)
```

**Семантический поиск:**
```python
from sentence_transformers import SentenceTransformer

model = SentenceTransformer('paraphrase-multilingual-MiniLM-L12-v2')

def semantic_search(query, clipboard_history):
    # Создаем embedding для запроса
    query_embedding = model.encode(query)
    
    # Сравниваем со всеми элементами истории
    similarities = []
    for entry in clipboard_history:
        similarity = cosine_similarity(query_embedding, entry['embedding'])
        similarities.append((entry, similarity))
    
    # Возвращаем top-5 наиболее похожих
    return sorted(similarities, key=lambda x: x[1], reverse=True)[:5]
```

### Пример интерфейса

```
Smart Clipboard Manager
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Search: [Найди тот email про встречу        ] 🔍

Results:
┌────────────────────────────────────────────┐
│ 🕐 Today 14:23 | Source: Gmail            │
│ john.doe@company.com                       │
│ "Hi, let's meet tomorrow at 3pm..."        │
│ Relevance: 95% ⭐⭐⭐⭐⭐                    │
│ [Copy] [Paste] [View Full] [Delete]       │
├────────────────────────────────────────────┤
│ 🕐 Today 11:45 | Source: Calendar         │
│ Meeting reminder: Project review           │
│ Relevance: 78% ⭐⭐⭐⭐                      │
│ [Copy] [Paste] [View Full] [Delete]       │
└────────────────────────────────────────────┘

Recent clipboard (last 10):
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
[1] 15:42 📄 "The project deadline is..."
[2] 15:40 🔗 https://github.com/user/repo
[3] 15:38 💻 def calculate_total(items):
[4] 15:35 📧 contact@client.com
[5] 15:30 🖼️ [Image: screenshot.png]
...

Quick actions:
[Merge selected items] [Export history] [Clear all]

Keyboard shortcuts:
• Ctrl+Shift+V : Search clipboard
• Ctrl+Alt+1-9 : Paste clipboard item 1-9
• Ctrl+Alt+H   : Show full history
```

### Расширенные возможности

**1. Clipboard collections:**
```
Создаешь коллекцию "Project Alpha quotes":
- Добавляешь 5 важных цитат из разных источников
- Потом: "Paste all quotes from Project Alpha"
→ Вставляет все 5 цитат форматированным списком
```

**2. Smart templates:**
```
Часто копируешь email + имя:
john.doe@company.com
John Doe

Claude запоминает паттерн, создает template:
[Email template for contacts]
{email}
{name}

В следующий раз предлагает:
"Хотите сохранить как контакт?"
```

**3. Cross-device sync:**
```
Копируешь на компьютере:
"Check this link: https://..."

Доступно на телефоне:
[Notification] "New clipboard from Desktop"
```

**4. Sensitive data detection:**
```
Копируешь пароль/API key:

Claude:
⚠️ Обнаружены чувствительные данные
Это выглядит как: API ключ
Срок хранения в истории: 5 минут
После этого будет автоматически удалён

[OK] [Don't save]
```

---

## Skill #8: Text Expander Pro
**Уровень сложности:** 🟡 Средний  
**Приоритет реализации:** 🔴 Высокий  
**Категория:** Текстовая обработка

### Описание
Интеллектуальное расширение текстовых сокращений с динамическим контентом и адаптацией под контекст.

### Проблема которую решает
- Печатаешь одни и те же фразы десятки раз в день
- Email шаблоны с небольшими вариациями
- Нужна персонализация, но хочется автоматизации
- Разные форматы ответов для разных платформ

### Существующие решения

**TextExpander (Mac/Windows, $40/year):**
```
Сокращение: ";email"
Расширяется в: "john.doe@company.com"
```
✅ Работает везде
✅ Синхронизация между устройствами
❌ Только статические шаблоны
❌ Нет адаптации под контекст

**Text Blaze (Chrome extension, free-$9/mo):**
```
Shortcut: /thanks
Template: "Thank you for your email, {formtext: name=Name}!"
```
✅ Динамические поля (нужно заполнить)
❌ Только в браузере
❌ Нужно помнить где какое поле

**Espanso (Open-source, бесплатный):**
```yaml
- trigger: ":hello"
  replace: "Hello, how are you?"
```
✅ Кроссплатформенный
✅ Мощный (поддерживает scripts)
❌ Сложная настройка (YAML файлы)
❌ Нет AI-адаптации

### Как Claude улучшает это

**Контекстно-зависимое расширение:**
```
Сокращение: ";thanks"

Вместо одного статического текста, Claude анализирует контекст:

В официальном email клиенту:
"Thank you for your inquiry. We appreciate your interest 
in our services and will respond within 24 hours."

В Slack коллеге:
"Thanks! 👍"

В email партнеру (история переписки учитывается):
"Dear Michael, thank you for the detailed proposal. 
We'll review it and get back to you by Friday."

→ Разные расширения в зависимости от:
- Платформы (email vs chat)
- Получателя (клиент vs коллега)
- Истории переписки
- Времени дня
```

**Умное заполнение данных:**
```
Статический TextExpander:
";sig"
→ "Best regards, John Doe
   Software Engineer
   john.doe@company.com"

Claude Text Expander:
";sig"

В письме клиенту (B2B):
→ "Best regards,
   John Doe
   Senior Software Engineer
   Company LLC
   john.doe@company.com
   +1-555-0123"

В casual email:
→ "Cheers,
   John"

В официальном документе:
→ "Sincerely yours,
   John Doe, MSc
   Senior Software Engineer"
```

### Конкретные Use Cases

**Use Case 1: Support менеджер**
```
Проблема: Отвечает на 50+ одинаковых вопросов в день

Настройка:
";refund" → "Шаблон ответа про возврат"
";track" → "Шаблон ответа про отслеживание"
";delay" → "Шаблон ответа про задержку"

Обычный Text Expander:
";refund"
→ "To process your refund, please reply with your order number."

Claude:
";refund" + анализирует email клиента

Если email содержит order number:
→ "Thank you for contacting us! I've initiated the refund 
   for order #12345. The funds will be returned to your 
   payment method within 5-7 business days."

Если order number нет:
→ "I'd be happy to help with your refund. Could you 
   please provide your order number? You can find it 
   in your confirmation email."

Если клиент расстроен (angry words):
→ "I sincerely apologize for the inconvenience. I 
   understand this is frustrating. Let me process 
   your refund immediately..."
```

**Use Case 2: Sales менеджер**
```
Сокращение: ";intro"

Контекст: Cold email новому лиду (из LinkedIn)

Claude:
"Hi [имя из LinkedIn],

I noticed you're working on [current company] as [position].
I thought you might be interested in [relevant product feature 
based on their industry].

Would you have 15 minutes next week for a quick call?"

→ Автоматически:
- Извлекает имя, компанию, позицию из LinkedIn
- Подбирает relevant product feature под индустрию
- Предлагает конкретное время (анализирует calendar)
```

**Use Case 3: Программист пишет документацию**
```
Сокращение: ";func"

Claude анализирует контекст кода:
```python
def calculate_discount(price, customer_type):
    ";func"
```

Расширяется в:
```python
def calculate_discount(price, customer_type):
    """
    Calculate discount based on customer type.
    
    Args:
        price (float): Original price of the product
        customer_type (str): Type of customer ('regular', 'premium', 'vip')
    
    Returns:
        float: Final price after applying discount
    
    Example:
        >>> calculate_discount(100, 'premium')
        85.0
    """
```

**Use Case 4: Многоязычная поддержка**
```
Сокращение: ";hello"

Пишешь email, Claude определяет язык получателя (из истории):

Получатель: Pierre (Франция)
→ "Bonjour Pierre,"

Получатель: Hans (Германия)
→ "Guten Tag Hans,"

Получатель: Иван (Россия)
→ "Добрый день, Иван!"

Получатель: John (США)
→ "Hi John,"
```

### Технические требования

**MCP серверы:**
- `mcp-keyboard` — перехват ввода
- `mcp-context-awareness` — определение активного приложения, получателя

**Keyboard hook (Python):**
```python
from pynput import keyboard
from pynput.keyboard import Key, Controller

class TextExpander:
    def __init__(self):
        self.current_text = ""
        self.shortcuts = {}  # будут подгружаться из Claude
        self.kb_controller = Controller()
    
    def on_key_press(self, key):
        try:
            self.current_text += key.char
        except AttributeError:
            if key == Key.space:
                self.check_for_shortcut()
                self.current_text = ""
    
    def check_for_shortcut(self):
        if self.current_text in self.shortcuts:
            # Удаляем сокращение
            for _ in range(len(self.current_text)):
                self.kb_controller.press(Key.backspace)
                self.kb_controller.release(Key.backspace)
            
            # Получаем контекст
            context = self.get_context()
            
            # Claude генерирует expanded text
            expanded = claude_expand(self.current_text, context)
            
            # Вводим расширенный текст
            self.kb_controller.type(expanded)
```

**Контекст для Claude:**
```python
def get_context():
    return {
        'active_app': get_active_application(),  # Gmail, Slack, VS Code...
        'recipient': extract_recipient(),  # email/name если доступно
        'conversation_history': get_recent_messages(limit=5),
        'time_of_day': datetime.now(),
        'user_calendar': get_next_meetings(),
        'clipboard_history': get_recent_clipboard(limit=3)
    }
```

### Пример настройки

```yaml
# shortcuts.yaml

shortcuts:
  ";email":
    description: "My email address"
    expand: "john.doe@company.com"
    
  ";phone":
    description: "My phone"
    expand: "+1-555-0123"
    
  ";addr":
    description: "Office address"
    expand: "123 Main St, San Francisco, CA 94105"
    
  ";thanks":
    description: "Thank you message (context-aware)"
    expand_with: claude
    variations:
      formal: "Thank you for your time and consideration."
      casual: "Thanks!"
      email_client: "Thank you for choosing our services."
    
  ";meet":
    description: "Schedule meeting (dynamic)"
    expand_with: claude
    template: "Would you be available for a {duration} {type} next {day}?"
    dynamic_fields:
      - duration: [15 min, 30 min, 1 hour]
      - type: [call, meeting, chat]
      - day: auto_suggest_from_calendar
```

### Интерфейс настройки

```
Text Expander Pro - Shortcuts Manager
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Активных shortcuts: 47 | За сегодня использовано: 123 раза

┌────────────────────────────────────────────────────┐
│ QUICK SHORTCUTS                                    │
├────────────────────────────────────────────────────┤
│ ";email" → john.doe@company.com                    │
│ ";phone" → +1-555-0123                             │
│ ";addr" → 123 Main St, San Francisco...            │
│ [Edit] [Delete]                                    │
└────────────────────────────────────────────────────┘

┌────────────────────────────────────────────────────┐
│ SMART SHORTCUTS (Claude-powered)                   │
├────────────────────────────────────────────────────┤
│ ";thanks" — Thank you message                      │
│ ├─ Context-aware: ✓                                │
│ ├─ Used: 34 times today                            │
│ └─ Variations: 3 (formal, casual, client)          │
│                                                     │
│ ";intro" — Introduction email                      │
│ ├─ Context-aware: ✓                                │
│ ├─ Auto-personalization: ✓                         │
│ └─ LinkedIn integration: ✓                         │
│                                                     │
│ ";meet" — Schedule meeting                         │
│ ├─ Calendar integration: ✓                         │
│ ├─ Auto-suggest times: ✓                           │
│ └─ Used: 12 times today                            │
│ [Edit] [View examples] [Delete]                    │
└────────────────────────────────────────────────────┘

[+ Add new shortcut]

Analytics:
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Top shortcuts this week:
1. ";thanks" — 234 uses (saved ~30 min)
2. ";sig" — 145 uses (saved ~15 min)
3. ";email" — 98 uses (saved ~5 min)

Total time saved this month: 4 hours 23 minutes
```

### Расширенные возможности

**1. Snippet with forms:**
```
";invoice"

Claude shows quick form:
┌─────────────────────────────┐
│ Create Invoice              │
├─────────────────────────────┤
│ Client: [Acme Corp ▼]       │
│ Amount: [$ 5,000]           │
│ Due date: [2024-02-15 📅]   │
│ Services: [Consulting]      │
│                             │
│ [Generate] [Cancel]         │
└─────────────────────────────┘

Generates full invoice email + PDF attachment
```

**2. Learning from corrections:**
```
Ты: ";thanks" → Claude expands
Claude: "Thank you for your email."

Ты редактируешь на: "Thanks for the quick reply!"

Claude learns:
"В этом контексте (colleague, Slack) пользователь 
предпочитает более casual style. Буду использовать 
'Thanks' вместо 'Thank you' в Slack."
```

**3. Snippet chaining:**
```
";newclient"

Автоматически вызывает цепочку:
1. ";intro" — вставляет приветствие
2. Claude ищет info о клиенте в CRM
3. ";services" — вставляет relevant services
4. ";cta" — вставляет call-to-action
5. ";sig" — вставляет подпись

Результат: полное персонализированное email за 1 команду
```

---

*Продолжение следует... Это первые 8 skills из 87. Хотите чтобы я продолжил с остальными skills по порядку?*
