# 🎓 ПОЛНОЕ РУКОВОДСТВО: КАК СОЗДАТЬ СВОЙ SKILL

**Версия:** 1.0  
**Дата:** 2024-01-27  
**Статус:** Complete Guide

---

## 📋 СОДЕРЖАНИЕ

1. [Что такое Skill](#что-такое-skill)
2. [Структура Skill файла](#структура-skill-файла)
3. [Варианты версий (Compact/Extended)](#варианты-версий)
4. [Пошаговое создание Skill](#пошаговое-создание-skill)
5. [Упаковка в .skill формат](#упаковка-в-skill-формат)
6. [Автоматическая установка](#автоматическая-установка)
7. [Подключение к другим Skills](#подключение-к-другим-skills)
8. [Примеры и шаблоны](#примеры-и-шаблоны)

---

## 🎯 ЧТО ТАКОЕ SKILL

### Определение

**Skill** - это расширение для Claude.ai, которое даёт Claude дополнительные знания и инструкции для выполнения специфических задач.

### Примеры Skills:

```
✅ Checkpoint Management Skill
   → Помогает создавать checkpoint для продолжения проектов

✅ Document Creation Skill
   → Помогает создавать документы по стандартам

✅ Code Review Skill
   → Помогает проверять код по best practices

✅ Translation Skill
   → Помогает переводить с соблюдением контекста
```

### Как работает:

```
БЕЗ SKILL:
User: "Создай checkpoint"
Claude: "Что такое checkpoint? Могу помочь..."

СО SKILL:
User: "Создай checkpoint"
Claude: [читает установленный skill]
        [следует инструкциям из skill]
        [создаёт checkpoint правильно] ✓
```

---

## 📁 СТРУКТУРА SKILL ФАЙЛА

### Минимальная структура:

```
my-skill/
└── SKILL.md
```

### Полная структура (с references):

```
my-skill/
├── SKILL.md (главный файл)
└── references/
    ├── examples.md
    ├── best-practices.md
    └── troubleshooting.md
```

### Содержимое SKILL.md:

```markdown
---
name: my-skill-name
description: Краткое описание что делает skill (макс 500 символов)
---

# Название Skill

## Когда использовать этот skill

[Описание когда Claude должен активировать этот skill]

## Основные инструкции

[Пошаговые инструкции что делать]

## Примеры

[Примеры использования]
```

---

## 🎨 ВАРИАНТЫ ВЕРСИЙ (COMPACT/EXTENDED)

### Зачем нужны 2 варианта?

```
COMPACT:
• Быстро читается (5-10 минут)
• Только essential информация
• Для быстрого старта
• 90% пользователей

EXTENDED:
• Полная документация (20-40 минут)
• Все детали и примеры
• Для глубокого изучения
• 10% пользователей (эксперты)
```

### Как создавать оба варианта:

```
my-skill-compact/
└── SKILL.md (150-200 строк)
    ├── YAML frontmatter
    ├── Quick intro
    ├── Essential instructions
    ├── 1-2 примера
    └── Quick reference

my-skill-extended/
└── SKILL.md (500-1000 строк)
    ├── YAML frontmatter
    ├── Detailed intro
    ├── Complete instructions
    ├── 5-10 примеров
    ├── Best practices
    ├── Troubleshooting
    ├── ROI calculations
    └── Use cases
```

---

## 🔨 ПОШАГОВОЕ СОЗДАНИЕ SKILL

### ШАГ 1: Определи цель

**Ответь на вопросы:**

```
1. Что должен делать skill?
   Пример: "Помогать создавать API документацию"

2. Для кого этот skill?
   Пример: "Для разработчиков, создающих REST API"

3. Какие проблемы решает?
   Пример: "Стандартизация документации, экономия времени"

4. Какие знания нужны Claude?
   Пример: "OpenAPI спецификация, REST best practices"
```

### ШАГ 2: Создай структуру папки

```bash
# Создай папку для skill
mkdir my-api-docs-skill

# Войди в папку
cd my-api-docs-skill

# Создай главный файл
touch SKILL.md

# (Опционально) Создай папку references
mkdir references
```

### ШАГ 3: Заполни YAML frontmatter

```yaml
---
name: my-api-docs-skill
description: "Помогает создавать полную API документацию по стандартам OpenAPI 3.0. Включает endpoints, schemas, authentication, examples. Для REST API разработчиков."
---
```

**ВАЖНЫЕ ПРАВИЛА YAML:**

```yaml
✅ ПРАВИЛЬНО:
name: my-skill-name
description: "Описание в кавычках если есть спецсимволы: колоны, запятые"

❌ НЕПРАВИЛЬНО:
name: my skill name  # Пробелы в имени
description: Описание: без кавычек  # Колон без кавычек

✅ ПРАВИЛЬНО - Multiline:
description: |
  Длинное описание
  на несколько строк
  работает так

✅ ПРАВИЛЬНО - С кавычками:
description: "Краткое описание (макс 500 символов) все в кавычках"
```

### ШАГ 4: Напиши основной контент

#### Структура SKILL.md:

```markdown
---
name: my-api-docs-skill
description: "Краткое описание"
---

# API Documentation Skill

## Когда использовать этот skill

Используй этот skill когда пользователь:
- Просит создать API документацию
- Упоминает REST API, endpoints, OpenAPI
- Спрашивает про API docs или Swagger
- Работает над API проектом

## Основная задача

Создать полную API документацию включая:
1. Overview
2. Authentication
3. Endpoints
4. Request/Response examples
5. Error codes
6. Rate limits

## Формат документации

Используй OpenAPI 3.0 спецификацию:

```yaml
openapi: 3.0.0
info:
  title: API Name
  version: 1.0.0
paths:
  /endpoint:
    get:
      summary: Description
      responses:
        200:
          description: Success
```

## Пошаговый процесс

1. **Собери информацию:**
   - Спроси про API endpoints
   - Узнай про authentication
   - Узнай базовый URL

2. **Создай структуру:**
   - Info section
   - Servers
   - Paths (endpoints)
   - Components (schemas)

3. **Заполни детали:**
   - Для каждого endpoint: method, path, parameters
   - Request/response examples
   - Error responses

4. **Добавь примеры:**
   - cURL examples
   - Code examples (Python, JS)
   - Response examples

## Примеры

### Пример 1: GET endpoint

```yaml
/users/{id}:
  get:
    summary: Get user by ID
    parameters:
      - name: id
        in: path
        required: true
        schema:
          type: integer
    responses:
      200:
        description: Success
        content:
          application/json:
            schema:
              $ref: '#/components/schemas/User'
```

### Пример 2: POST endpoint

```yaml
/users:
  post:
    summary: Create user
    requestBody:
      required: true
      content:
        application/json:
          schema:
            $ref: '#/components/schemas/CreateUser'
    responses:
      201:
        description: Created
```

## Best Practices

1. ✅ Всегда указывай response examples
2. ✅ Документируй все error codes
3. ✅ Указывай required/optional поля
4. ✅ Добавляй descriptions ко всем полям
5. ✅ Используй $ref для переиспользования schemas

## Контрольный чеклист

Перед финализацией проверь:

- [ ] Все endpoints документированы
- [ ] Authentication описан
- [ ] Examples для всех endpoints
- [ ] Error responses указаны
- [ ] Schemas определены
- [ ] Rate limits указаны (если есть)

## Troubleshooting

**Проблема:** Пользователь не знает все endpoints
**Решение:** Создай документацию для известных, пометь TODO для остальных

**Проблема:** Нет примеров responses
**Решение:** Создай типичные примеры на основе schema

## Финальный Output

Создай файл `api-documentation.yaml` с полной OpenAPI спецификацией.
```

### ШАГ 5: (Опционально) Добавь reference файлы

**references/examples.md:**

```markdown
# Примеры API Documentation

## Пример 1: Simple REST API

[Полный пример...]

## Пример 2: API с Authentication

[Полный пример...]
```

**references/best-practices.md:**

```markdown
# Best Practices

1. Naming conventions
2. Versioning
3. Error handling
...
```

---

## 📦 УПАКОВКА В .skill ФОРМАТ

### СПОСОБ 1: Используя Python скрипт (РЕКОМЕНДУЕТСЯ)

```bash
# В директории где лежит твоя папка skill
python3 /mnt/skills/examples/skill-creator/scripts/package_skill.py \
  my-api-docs-skill \
  /path/to/output/directory

# Результат: my-api-docs-skill.skill создан
```

### СПОСОБ 2: Вручную через ZIP

```bash
# 1. Перейди в РОДИТЕЛЬСКУЮ директорию
cd /path/to/parent/

# 2. Создай ZIP архив
zip -r my-api-docs-skill.skill my-api-docs-skill/

# 3. Проверь содержимое
unzip -l my-api-docs-skill.skill

# Должно быть:
# my-api-docs-skill/SKILL.md
# my-api-docs-skill/references/... (если есть)
```

### СПОСОБ 3: Через Claude в чате

```markdown
Напиши Claude:

"Упакуй эту skill папку в .skill формат:
[прикрепи файлы]

Структура:
my-skill/
└── SKILL.md"

Claude использует bash команды для создания .skill файла
```

---

## ⚙️ АВТОМАТИЧЕСКАЯ УСТАНОВКА

### Формат .skill файла:

```
my-skill.skill
└── (это ZIP архив с расширением .skill)
    └── my-skill/
        ├── SKILL.md
        └── references/ (опционально)
```

### Требования для автоустановки:

```
✅ 1. Правильное имя файла: my-skill.skill
✅ 2. Правильная структура внутри:
      my-skill/SKILL.md (НЕ просто SKILL.md в корне!)
✅ 3. Валидный YAML frontmatter
✅ 4. Расширение .skill (не .zip!)
```

### Установка через Claude.ai:

```
1. Открой claude.ai
2. Settings → Skills
3. "Upload Skill"
4. Выбери .skill файл
5. Claude автоматически:
   - Проверяет формат ✓
   - Читает YAML ✓
   - Устанавливает skill ✓
   - Активирует его ✓
6. Готово! Skill работает ✅
```

### Проверка установки:

```
1. Открой новый чат
2. Напиши trigger фразу для твоего skill
3. Claude должен активировать skill
4. Если не работает → проверь YAML и структуру
```

---

## 🔗 ПОДКЛЮЧЕНИЕ К ДРУГИМ SKILLS

### Как Skills взаимодействуют:

```
User: "Создай checkpoint и документацию API"

Claude:
1. Видит 2 задачи
2. Активирует Checkpoint Skill
3. Создаёт checkpoint ✓
4. Активирует API Docs Skill
5. Создаёт API docs ✓
6. Оба skills работают вместе!
```

### Явное упоминание других skills:

В твоём SKILL.md можно писать:

```markdown
## Интеграция с другими skills

Этот skill работает вместе с:

1. **Checkpoint Management Skill**
   - Используй когда нужно сохранить прогресс
   - Команда: "Создай checkpoint"

2. **Code Review Skill**
   - Используй для проверки сгенерированного кода
   - Команда: "Проверь этот код"

### Пример workflow:

1. Создай API docs (этот skill)
2. Создай checkpoint (другой skill)
3. Review код (третий skill)
```

### Best Practices для интеграции:

```markdown
✅ Упоминай имена других skills
✅ Указывай когда их использовать
✅ Добавляй примеры workflows
✅ Объясняй как они дополняют друг друга

❌ Не дублируй функциональность других skills
❌ Не конфликтуй с другими skills
❌ Не перегружай один skill слишком многим
```

---

## 📝 ПРИМЕРЫ И ШАБЛОНЫ

### ШАБЛОН 1: Minimal Skill

```markdown
---
name: my-minimal-skill
description: "Краткое описание (одна строка)"
---

# My Minimal Skill

## Когда использовать

[Условия активации]

## Что делать

[Инструкции]

## Пример

[Один пример]
```

**Размер:** 50-100 строк  
**Время чтения:** 2-3 минуты  
**Для:** Очень простых задач

---

### ШАБЛОН 2: Standard Skill (Compact)

```markdown
---
name: my-standard-skill
description: "Полное описание что делает skill и для кого"
---

# My Standard Skill

## Когда использовать этот skill

[Trigger условия]

## Основная задача

[Главная цель]

## Пошаговый процесс

1. Шаг 1
2. Шаг 2
3. Шаг 3

## Примеры

### Пример 1
[Код/текст]

### Пример 2
[Код/текст]

## Контрольный чеклист

- [ ] Пункт 1
- [ ] Пункт 2

## Финальный Output

[Что создаётся в итоге]
```

**Размер:** 150-250 строк  
**Время чтения:** 5-10 минут  
**Для:** Стандартных задач

---

### ШАБЛОН 3: Extended Skill

```markdown
---
name: my-extended-skill
description: "Полное описание с деталями"
---

# My Extended Skill

## Table of Contents

1. [Когда использовать](#когда-использовать)
2. [Основная задача](#основная-задача)
3. [Детальные инструкции](#детальные-инструкции)
4. [Примеры](#примеры)
5. [Best Practices](#best-practices)
6. [Troubleshooting](#troubleshooting)

## Когда использовать

[Подробное описание trigger условий]

## Основная задача

[Детальное описание]

## Детальные инструкции

### Фаза 1: Подготовка
[Детали...]

### Фаза 2: Выполнение
[Детали...]

### Фаза 3: Финализация
[Детали...]

## Примеры

### Пример 1: Basic Use Case
[Детальный пример с комментариями]

### Пример 2: Advanced Use Case
[Детальный пример с объяснениями]

### Пример 3: Edge Case
[Как обрабатывать особые случаи]

## Best Practices

### DO ✅
1. Практика 1
2. Практика 2

### DON'T ❌
1. Антипаттерн 1
2. Антипаттерн 2

## Troubleshooting

### Проблема 1
**Симптомы:** [...]
**Причина:** [...]
**Решение:** [...]

### Проблема 2
[Аналогично...]

## Advanced Features

[Дополнительные возможности]

## Интеграция с другими skills

[Как работает с другими skills]

## ROI & Metrics

[Экономия времени, улучшения качества]

## Контрольный чеклист

- [ ] Этап 1
- [ ] Этап 2
- [ ] Проверка качества
- [ ] Финальная валидация

## Финальный Output

[Детальное описание результата]

## Appendix

### Appendix A: Glossary
[Термины]

### Appendix B: References
[Ссылки]
```

**Размер:** 500-1000 строк  
**Время чтения:** 20-40 минут  
**Для:** Сложных профессиональных задач

---

## 🎯 CHECKLIST: СОЗДАНИЕ SKILL

```
ПЛАНИРОВАНИЕ:
□ Определил цель skill
□ Определил целевую аудиторию
□ Определил trigger условия
□ Составил список функций

СТРУКТУРА:
□ Создал папку my-skill/
□ Создал SKILL.md
□ (Опционально) Создал references/

YAML FRONTMATTER:
□ Добавил name
□ Добавил description
□ Проверил валидность YAML
□ Поставил кавычки где нужно

КОНТЕНТ:
□ Написал "Когда использовать"
□ Написал "Основная задача"
□ Написал пошаговые инструкции
□ Добавил примеры (минимум 2)
□ Добавил checklists
□ (Опционально) Добавил best practices
□ (Опционально) Добавил troubleshooting

УПАКОВКА:
□ Упаковал в .skill формат
□ Проверил структуру архива
□ Проверил имя файла
□ Проверил расширение .skill

ТЕСТИРОВАНИЕ:
□ Установил skill в Claude.ai
□ Протестировал trigger фразы
□ Проверил что Claude следует инструкциям
□ Проверил примеры работают
□ (Опционально) Протестировал с другими skills

ФИНАЛИЗАЦИЯ:
□ Исправил найденные проблемы
□ Обновил документацию
□ Создал README (опционально)
□ Готов к распространению ✅
```

---

## 💡 СОВЕТЫ И BEST PRACTICES

### Для YAML frontmatter:

```yaml
✅ DO:
- Используй кавычки для описаний
- Проверяй YAML на валидность
- Используй kebab-case для имён (my-skill-name)

❌ DON'T:
- Не используй пробелы в name
- Не используй колоны без кавычек
- Не превышай 500 символов в description
```

### Для контента:

```markdown
✅ DO:
- Пиши ясно и конкретно
- Используй примеры
- Добавляй checklists
- Структурируй информацию

❌ DON'T:
- Не пиши слишком много (compact: макс 250 строк)
- Не используй сложный язык
- Не забывай примеры
- Не дублируй другие skills
```

### Для trigger условий:

```markdown
✅ DO:
- Будь специфичным
- Используй ключевые слова
- Добавляй контекст
Пример: "Когда пользователь просит 'создать API документацию'
         или упоминает 'REST API', 'endpoints', 'OpenAPI'"

❌ DON'T:
- Не будь слишком общим
- Не перекрывайся с другими skills
Пример: "Когда пользователь что-то просит" ❌
```

### Для совместимости с другими skills:

```markdown
✅ DO:
- Упоминай имена других skills
- Объясняй как они работают вместе
- Добавляй примеры workflows
- Избегай конфликтов

❌ DON'T:
- Не дублируй функциональность
- Не создавай противоречия
- Не перегружай один skill
```

---

## 🚀 QUICK START: СОЗДАЙ SKILL ЗА 15 МИНУТ

```bash
# 1. Создай папку (1 минута)
mkdir my-first-skill
cd my-first-skill

# 2. Создай SKILL.md (10 минут)
# Скопируй ШАБЛОН 2 (Standard Skill)
# Заполни своими данными

# 3. Упакуй в .skill (2 минуты)
cd ..
zip -r my-first-skill.skill my-first-skill/

# 4. Установи в Claude.ai (2 минуты)
# Settings → Skills → Upload
# Выбери my-first-skill.skill

# 5. Протестируй!
# Открой новый чат
# Используй trigger фразу
# ✅ Работает!
```

---

## 📚 ДОПОЛНИТЕЛЬНЫЕ РЕСУРСЫ

### Официальные примеры:

```
/mnt/skills/examples/
├── skill-creator/    (этот гайд использует его)
├── doc-coauthoring/  (пример skill для документов)
├── web-artifacts-builder/  (пример для web)
└── ... (другие примеры)
```

### Валидация YAML:

```bash
# Проверь YAML онлайн:
# https://www.yamllint.com/

# Или используй Python:
python3 -c "import yaml; yaml.safe_load(open('SKILL.md').read())"
```

### Тестирование skill:

```markdown
1. Установи skill
2. Открой новый чат
3. Используй разные trigger фразы
4. Проверь что Claude:
   - Активирует skill ✓
   - Следует инструкциям ✓
   - Создаёт правильный output ✓
5. Если что-то не работает:
   - Проверь YAML
   - Проверь trigger условия
   - Уточни инструкции
```

---

## ❓ FAQ

### Q: Сколько skills можно установить?
**A:** Неограниченно! Можно установить все которые нужны.

### Q: Будут ли skills конфликтовать?
**A:** Нет, если правильно написаны trigger условия.

### Q: Можно ли обновить skill?
**A:** Да! Просто переустанови обновлённую версию.

### Q: Можно ли делиться skills?
**A:** Да! Просто отправь .skill файл другим.

### Q: Какой размер оптимальный?
**A:** 
- Compact: 150-250 строк
- Extended: 500-1000 строк
- Minimal: 50-100 строк

### Q: Нужно ли создавать 2 варианта (compact/extended)?
**A:** Не обязательно. Для начала создай один вариант.

### Q: Как назвать skill?
**A:** Используй kebab-case: `my-skill-name`

### Q: YAML не проходит валидацию?
**A:** Проверь:
- Кавычки вокруг description
- Нет ли лишних колонов
- Правильный отступ (2 пробела)

---

## 🎉 ЗАКЛЮЧЕНИЕ

Теперь ты знаешь:

✅ Что такое skill  
✅ Как создать структуру  
✅ Как написать YAML frontmatter  
✅ Как написать контент  
✅ Как упаковать в .skill  
✅ Как установить автоматически  
✅ Как интегрировать с другими skills  

**Следующие шаги:**

1. Выбери идею для своего skill
2. Используй шаблон (Standard рекомендуется)
3. Заполни своими данными
4. Упакуй и протестируй
5. Делись с другими! 🚀

---

**Happy Skill Creating!** 🎓

*От простой идеи до работающего skill за 15 минут!*
