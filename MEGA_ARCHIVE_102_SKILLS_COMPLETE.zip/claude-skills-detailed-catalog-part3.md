# Детальный каталог Claude Skills: Skills #12-18

## УРОВЕНЬ 1 — БАЗОВЫЕ SKILLS (продолжение)

### КАТЕГОРИЯ 1.3: БАЗОВОЕ ФОРМАТИРОВАНИЕ (продолжение)

---

## Skill #12: Table Beautifier
**Уровень сложности:** 🟡 Средний  
**Приоритет реализации:** 🟡 Средний  
**Категория:** Базовое форматирование

### Описание
Автоматическое форматирование, выравнивание и конвертация таблиц между различными форматами (CSV, Markdown, HTML, ASCII, Excel) с умным определением структуры.

### Проблема которую решает
- Таблицы в plain text выглядят неаккуратно
- CSV нужно конвертировать в Markdown для документации
- Данные из Excel нужны в ASCII для email/терминала
- Колонки не выровнены, трудно читать
- Нужно автоматически создать таблицу из неструктурированного текста

### Существующие решения и их ограничения

**CSV to Markdown converters (online):**
```
Input CSV:
name,age,city
John,25,NYC
Jane,30,LA

Output:
| name | age | city |
|------|-----|------|
| John | 25  | NYC  |
| Jane | 30  | LA   |
```
✅ Базовая конвертация работает
❌ Нет умного выравнивания
❌ Не определяет типы данных (числа должны быть right-aligned)
❌ Не обрабатывает сложные случаи (merged cells, multi-line content)

**csvkit (командная строка):**
```bash
csvlook data.csv  # Pretty-print CSV
```
✅ Удобно для терминала
❌ Только для CSV
❌ Ограниченное форматирование

**Excel:**
✅ Мощное форматирование таблиц
❌ GUI-инструмент
❌ Не для автоматизации
❌ Платный

**Python pandas:**
```python
import pandas as pd
df = pd.read_csv('data.csv')
print(df.to_markdown())
```
✅ Программное решение
❌ Требует знания Python
❌ Нужно писать скрипт для каждого случая

### Как Claude улучшает это

**Умное определение структуры:**

**Input:** Неструктурированный текст
```
Product list:
iPhone 14 Pro costs $999 available in stores
MacBook Air is $1299 online only
iPad Pro priced at $799 both online and stores
```

**Команда:** "Преобразуй в таблицу"

**Claude анализирует:**
- Распознаёт паттерн: Product, Price, Availability
- Извлекает данные
- Создаёт структурированную таблицу

**Output:**
```
| Product        | Price  | Availability      |
|----------------|--------|-------------------|
| iPhone 14 Pro  | $999   | In stores         |
| MacBook Air    | $1,299 | Online only       |
| iPad Pro       | $799   | Online and stores |
```

**Умное выравнивание по типу данных:**

**Традиционная таблица:**
```
| Name | Age | Salary |
|------|-----|--------|
| John Smith | 25 | $50000 |
| Jane | 30 | $75000 |
| Bob Johnson | 45 | $100000 |
```
❌ Все колонки left-aligned, трудно читать числа

**Claude:**
```
| Name        | Age | Salary   |
|:------------|----:|---------:|
| John Smith  |  25 | $50,000  |
| Jane        |  30 | $75,000  |
| Bob Johnson |  45 | $100,000 |
```
✓ Текст left-aligned (`:----------`)
✓ Числа right-aligned (`----:`, `---------:`)
✓ Добавлены разделители тысяч ($50,000)

**Адаптивное форматирование под целевой формат:**

**Одна таблица → разные представления:**

**Для Markdown (GitHub README):**
```markdown
| Feature    | Free | Pro    | Enterprise |
|:-----------|:----:|:------:|:----------:|
| Storage    | 5GB  | 100GB  | Unlimited  |
| Users      | 1    | 10     | Unlimited  |
| Support    | ❌   | ✅     | 24/7       |
```

**Для ASCII email:**
```
┌────────────┬──────┬────────┬────────────┐
│ Feature    │ Free │ Pro    │ Enterprise │
├────────────┼──────┼────────┼────────────┤
│ Storage    │ 5GB  │ 100GB  │ Unlimited  │
│ Users      │ 1    │ 10     │ Unlimited  │
│ Support    │ No   │ Yes    │ 24/7       │
└────────────┴──────┴────────┴────────────┘
```

**Для HTML:**
```html
<table class="styled-table">
  <thead>
    <tr>
      <th>Feature</th>
      <th>Free</th>
      <th>Pro</th>
      <th>Enterprise</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>Storage</td>
      <td>5GB</td>
      <td>100GB</td>
      <td>Unlimited</td>
    </tr>
    <!-- ... -->
  </tbody>
</table>
```

### Конкретные Use Cases

**Use Case 1: Программист форматирует SQL результаты**
```
Ситуация: SQL query вернул результаты, нужно показать в Slack

SQL output:
id,name,email,created_at
1,John,john@email.com,2024-01-15
2,Jane,jane@email.com,2024-01-20
3,Bob,bob@email.com,2024-01-22

Команда: "Форматируй как таблицу для Slack"

Claude создаёт ASCII таблицу:
```
┌────┬──────┬──────────────────┬────────────┐
│ ID │ Name │ Email            │ Created    │
├────┼──────┼──────────────────┼────────────┤
│  1 │ John │ john@email.com   │ 2024-01-15 │
│  2 │ Jane │ jane@email.com   │ 2024-01-20 │
│  3 │ Bob  │ bob@email.com    │ 2024-01-22 │
└────┴──────┴──────────────────┴────────────┘
```

**Use Case 2: Техписатель создаёт документацию**
```
Ситуация: API documentation, нужна таблица endpoints

Input (неструктурированный текст):
GET /users returns list of users
POST /users creates new user requires name and email
DELETE /users/:id deletes user by id admin only

Команда: "Создай таблицу API endpoints"

Claude:
| Method | Endpoint     | Description       | Auth Required |
|:------:|:-------------|:------------------|:-------------:|
| GET    | /users       | List all users    | No            |
| POST   | /users       | Create new user   | Yes           |
| DELETE | /users/:id   | Delete user by ID | Admin         |

Claude автоматически:
- Определил структуру
- Извлёк HTTP методы
- Создал колонку Auth Required
- Выровнял по смыслу
```

**Use Case 3: Аналитик готовит отчёт**
```
Ситуация: Excel таблица с финансами → нужен красивый отчёт для email

Input Excel:
Quarter | Revenue | Expenses | Profit
Q1 2024 | 1500000 | 1200000  | 300000
Q2 2024 | 1800000 | 1300000  | 500000
Q3 2024 | 2100000 | 1400000  | 700000

Команда: "Форматируй для email отчёта, добавь total row и проценты"

Claude:
┌─────────┬───────────┬───────────┬──────────┬────────────┐
│ Quarter │ Revenue   │ Expenses  │ Profit   │ Margin %   │
├─────────┼───────────┼───────────┼──────────┼────────────┤
│ Q1 2024 │ $1,500,000│ $1,200,000│ $300,000 │    20.0%   │
│ Q2 2024 │ $1,800,000│ $1,300,000│ $500,000 │    27.8%   │
│ Q3 2024 │ $2,100,000│ $1,400,000│ $700,000 │    33.3%   │
├─────────┼───────────┼───────────┼──────────┼────────────┤
│ TOTAL   │ $5,400,000│ $3,900,000│$1,500,000│    27.8%   │
└─────────┴───────────┴───────────┴──────────┴────────────┘

Claude добавил:
- Форматирование чисел ($1,500,000)
- Вычисленную колонку Margin %
- Total row с суммами
- Box-drawing characters для красоты
```

**Use Case 4: DevOps Engineer — лог анализ**
```
Ситуация: Логи сервера, нужно найти паттерны

Raw logs:
[2024-01-27 10:15:23] ERROR user_id=123 endpoint=/api/users response_time=5234ms
[2024-01-27 10:16:45] ERROR user_id=456 endpoint=/api/orders response_time=8932ms
[2024-01-27 10:17:12] ERROR user_id=789 endpoint=/api/users response_time=6123ms

Команда: "Извлеки данные в таблицу, отсортируй по response_time"

Claude:
| Time     | User ID | Endpoint     | Response Time |
|:---------|--------:|:-------------|--------------:|
| 10:16:45 |     456 | /api/orders  |      8,932 ms |
| 10:17:12 |     789 | /api/users   |      6,123 ms |
| 10:15:23 |     123 | /api/users   |      5,234 ms |

Замечание от Claude:
"⚠️ Endpoint /api/orders имеет самое большое время ответа (8.9s).
   Рекомендую проверить производительность этого endpoint."
```

**Use Case 5: Студент форматирует данные для работы**
```
Ситуация: Копирует таблицу из PDF, она сломана

Copy-paste из PDF:
Name         Age City
John Smith 25
NYC
Jane    Doe     30 Los Angeles
Bob 45 Chicago

Команда: "Исправь эту таблицу"

Claude распознаёт структуру:
| Name       | Age | City        |
|:-----------|----:|:------------|
| John Smith |  25 | NYC         |
| Jane Doe   |  30 | Los Angeles |
| Bob        |  45 | Chicago     |

Claude исправил:
- Перенос строк (NYC был на новой строке)
- Лишние пробелы (Jane    Doe)
- Выравнивание
```

### Технические требования

**MCP серверы:**
- `mcp-filesystem` — чтение CSV/TSV файлов
- `mcp-document-readers` — чтение Excel файлов

**Python библиотеки:**
```python
import pandas as pd
from tabulate import tabulate
import csv
from io import StringIO
```

**Базовая архитектура:**
```python
class TableBeautifier:
    def __init__(self):
        self.formats = {
            'markdown': self.to_markdown,
            'ascii': self.to_ascii,
            'html': self.to_html,
            'latex': self.to_latex,
            'csv': self.to_csv,
        }
    
    def beautify(self, input_data, output_format='markdown', options=None):
        """
        Главная функция форматирования таблиц
        """
        # 1. Определяем входной формат
        input_format = self.detect_input_format(input_data)
        
        # 2. Парсим в DataFrame
        if input_format == 'csv':
            df = pd.read_csv(StringIO(input_data))
        elif input_format == 'excel':
            df = pd.read_excel(input_data)
        elif input_format == 'markdown':
            df = self.parse_markdown_table(input_data)
        elif input_format == 'text':
            # Claude пытается извлечь табличные данные из текста
            df = claude_extract_table(input_data)
        
        # 3. Claude анализирует типы данных
        column_types = self.analyze_column_types(df)
        
        # 4. Применяем умное форматирование
        df = self.apply_smart_formatting(df, column_types)
        
        # 5. Конвертируем в целевой формат
        formatter = self.formats[output_format]
        return formatter(df, column_types, options)
    
    def analyze_column_types(self, df):
        """
        Определяет тип данных в каждой колонке
        """
        types = {}
        for col in df.columns:
            # Проверяем содержимое
            sample = df[col].dropna().head(10)
            
            if all(isinstance(x, (int, float)) for x in sample):
                types[col] = 'numeric'
            elif all(self.is_currency(str(x)) for x in sample):
                types[col] = 'currency'
            elif all(self.is_date(str(x)) for x in sample):
                types[col] = 'date'
            elif all(self.is_percentage(str(x)) for x in sample):
                types[col] = 'percentage'
            else:
                types[col] = 'text'
        
        return types
    
    def to_markdown(self, df, column_types, options):
        """
        Конвертация в Markdown с умным выравниванием
        """
        # Определяем выравнивание для каждой колонки
        alignments = []
        for col in df.columns:
            col_type = column_types.get(col, 'text')
            if col_type in ['numeric', 'currency', 'percentage']:
                alignments.append('right')
            elif col_type == 'date':
                alignments.append('center')
            else:
                alignments.append('left')
        
        # Используем tabulate с настройками
        return tabulate(
            df,
            headers='keys',
            tablefmt='pipe',
            showindex=False,
            numalign='right',
            stralign='left',
            colalign=alignments
        )
    
    def to_ascii(self, df, column_types, options):
        """
        Красивая ASCII таблица с box-drawing characters
        """
        return tabulate(
            df,
            headers='keys',
            tablefmt='fancy_grid',  # ┌─┬─┐ style
            showindex=False
        )
```

**Умное форматирование чисел:**
```python
def apply_smart_formatting(df, column_types):
    """
    Применяет форматирование к данным
    """
    df_formatted = df.copy()
    
    for col in df.columns:
        col_type = column_types.get(col, 'text')
        
        if col_type == 'currency':
            # Форматируем как валюту
            df_formatted[col] = df[col].apply(
                lambda x: f"${x:,.2f}" if pd.notna(x) else ""
            )
        
        elif col_type == 'numeric':
            # Добавляем разделители тысяч
            df_formatted[col] = df[col].apply(
                lambda x: f"{x:,}" if pd.notna(x) else ""
            )
        
        elif col_type == 'percentage':
            # Форматируем проценты
            df_formatted[col] = df[col].apply(
                lambda x: f"{x:.1f}%" if pd.notna(x) else ""
            )
        
        elif col_type == 'date':
            # Нормализуем даты
            df_formatted[col] = pd.to_datetime(df[col]).dt.strftime('%Y-%m-%d')
    
    return df_formatted
```

**Извлечение таблицы из текста (Claude):**
```python
def claude_extract_table(text):
    """
    Claude анализирует текст и пытается извлечь табличные данные
    """
    prompt = f"""
    Extract tabular data from this text.
    
    Text:
    {text}
    
    Return as CSV format with headers.
    """
    
    csv_data = claude_api(prompt)
    
    # Парсим CSV
    df = pd.read_csv(StringIO(csv_data))
    return df
```

### Пример интерфейса

```
Table Beautifier
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Input format:
  (•) CSV file
  ( ) Excel file
  ( ) Markdown table
  ( ) Plain text (auto-extract)
  ( ) Paste from clipboard

[Choose file...] data.csv

Output format:
  (•) Markdown (GitHub-style)
  ( ) ASCII (box-drawing)
  ( ) HTML table
  ( ) LaTeX
  ( ) CSV (reformatted)

Options:
  ☑ Auto-align by data type
  ☑ Add thousand separators
  ☑ Sort by column: [Revenue ▼]
  ☐ Add total row
  ☐ Highlight max/min values
  ☐ Add row numbers

Preview:
┌──────────────────────────────────────────────┐
│ | Product     | Q1 Sales | Q2 Sales |       │
│ |:------------|----------|----------|       │
│ | iPhone      |   $1,500 |   $2,100 |       │
│ | MacBook     |   $3,200 |   $3,800 |       │
│ | iPad        |     $890 |   $1,200 |       │
└──────────────────────────────────────────────┘

[Generate] [Copy to clipboard] [Save file]
```

### Расширенные возможности

**1. Conditional formatting (для HTML):**
```python
def apply_conditional_formatting(df, rules):
    """
    Применяет условное форматирование
    
    rules = {
        'Revenue': {
            'high': {'condition': '> 1000000', 'color': 'green'},
            'low': {'condition': '< 500000', 'color': 'red'}
        }
    }
    """
    
    styled_df = df.style
    
    for col, conditions in rules.items():
        for rule_name, rule in conditions.items():
            # Apply color based on condition
            styled_df = styled_df.applymap(
                lambda x: f'background-color: {rule["color"]}' 
                if eval(f'x {rule["condition"]}') else '',
                subset=[col]
            )
    
    return styled_df.to_html()
```

**2. Table merging:**
```
Команда: "Объедини эти две таблицы по колонке 'ID'"

Table 1:
| ID | Name |
|----|------|
| 1  | John |
| 2  | Jane |

Table 2:
| ID | Email          |
|----|----------------|
| 1  | john@email.com |
| 2  | jane@email.com |

Result:
| ID | Name | Email          |
|----|------|----------------|
| 1  | John | john@email.com |
| 2  | Jane | jane@email.com |
```

**3. Pivot tables:**
```
Input:
| Date       | Product | Sales |
|------------|---------|-------|
| 2024-01-15 | iPhone  | 100   |
| 2024-01-15 | iPad    | 50    |
| 2024-01-20 | iPhone  | 120   |

Команда: "Создай pivot table: Products as rows, Dates as columns"

Result:
| Product | 2024-01-15 | 2024-01-20 |
|---------|------------|------------|
| iPhone  |        100 |        120 |
| iPad    |         50 |          - |
```

**4. Sparklines в ASCII:**
```
Команда: "Добавь sparkline график для трендов"

| Product | Q1    | Q2    | Q3    | Q4    | Trend      |
|---------|-------|-------|-------|-------|------------|
| iPhone  | $1000 | $1200 | $1500 | $1800 | ▁▃▅█       |
| iPad    | $800  | $750  | $900  | $850  | █▅▇▆       |
| MacBook | $2000 | $2100 | $1900 | $2200 | █▇▅█       |
```

---

## Skill #13: Code Formatter Universal
**Уровень сложности:** 🟢 Базовый  
**Приоритет реализации:** 🟢 Низкий  
**Категория:** Базовое форматирование

### Описание
Универсальное форматирование кода на любом языке программирования одной командой, с объяснением изменений и соблюдением best practices.

### Проблема которую решает
- Разный code style в проекте
- Нужно форматировать код на разных языках (Python, JS, Go, Rust...)
- Каждый язык — свой formatter (Black, Prettier, gofmt...)
- Непонятно какие настройки использовать
- Code review тратится на споры о formatting

### Существующие решения и их ограничения

**Language-specific formatters:**

**Python — Black:**
```bash
black myfile.py
```
✅ Opinionated, no config needed
❌ Только Python

**JavaScript — Prettier:**
```bash
prettier --write myfile.js
```
✅ Поддерживает JS, TS, JSX, CSS, HTML
❌ Нужна настройка для каждого проекта

**Go — gofmt:**
```bash
gofmt -w myfile.go
```
✅ Встроен в Go, standard
❌ Только Go

**Rust — rustfmt:**
```bash
rustfmt myfile.rs
```
✅ Официальный formatter
❌ Только Rust

**Проблема:**
- Нужно знать и настраивать отдельный инструмент для каждого языка
- Разные конфигурации (.prettierrc, .rustfmt.toml, pyproject.toml)
- Сложно поддерживать consistency в мультиязычных проектах

**EditorConfig:**
```ini
[*.py]
indent_style = space
indent_size = 4

[*.js]
indent_style = space
indent_size = 2
```
✅ Универсальная конфигурация
❌ Только базовые настройки (indent, line ending)
❌ Не форматирует сам код

### Как Claude улучшает это

**Единая команда для всех языков:**

```
Команда: "Форматируй этот код"

Claude автоматически:
1. Определяет язык программирования
2. Применяет соответствующий formatter
3. Использует best practices для этого языка
4. Объясняет что изменилось
```

**Примеры:**

**Python (неформатированный):**
```python
def calculate(x,y):
    if x>y:
        return x-y
    else:
        return y-x
```

**Claude:**
```python
def calculate(x, y):
    if x > y:
        return x - y
    else:
        return y - x
```

Изменения:
- ✓ Добавлены пробелы после запятых в параметрах
- ✓ Добавлены пробелы вокруг операторов (>, -, )
- ✓ Соответствует PEP 8

**JavaScript (неформатированный):**
```javascript
function getData(){
  return fetch('/api/data').then(response=>response.json()).catch(error=>{console.error(error)})
}
```

**Claude:**
```javascript
function getData() {
  return fetch("/api/data")
    .then((response) => response.json())
    .catch((error) => {
      console.error(error);
    });
}
```

Изменения:
- ✓ Пробел после function name
- ✓ Promise chain разбит на строки
- ✓ Arrow functions с явными параметрами
- ✓ Точка с запятой добавлена
- ✓ Соответствует Airbnb style guide

**Умное объяснение изменений:**

```
Команда: "Форматируй и объясни что изменилось"

Claude:
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
ФОРМАТИРОВАНИЕ ЗАВЕРШЕНО
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Изменено: 12 строк
Язык: Python
Стандарт: PEP 8

Основные изменения:

1. Добавлены пробелы вокруг операторов (5 мест)
   Было: x>y
   Стало: x > y
   Причина: PEP 8 требует пробелы для читаемости

2. Исправлена длина строки (2 места)
   Было: very_long_function_name_that_exceeds_line_limit(param1, param2, param3)
   Стало: 
     very_long_function_name_that_exceeds_line_limit(
         param1, param2, param3
     )
   Причина: PEP 8 рекомендует max 79 символов

3. Упорядочены импорты (3 блока)
   Порядок: standard library → third-party → local
   Причина: PEP 8 convention

4. Добавлены docstrings (2 функции)
   Причина: Best practice для public functions
```

### Конкретные Use Cases

**Use Case 1: Новый разработчик в команде**
```
Ситуация: Написал код, не знает code style команды

Новичок пишет:
function processData(data){
for(let i=0;i<data.length;i++){
console.log(data[i])
}
}

Команда: "Форматируй по code style нашего проекта"

Claude анализирует .prettierrc в проекте:
{
  "semi": true,
  "singleQuote": true,
  "tabWidth": 2
}

Форматирует соответственно:
function processData(data) {
  for (let i = 0; i < data.length; i++) {
    console.log(data[i]);
  }
}
```

**Use Case 2: Code review — фокус на логике, не на formatting**
```
Ситуация: Pull request с логическими изменениями + плохое форматирование

Before (hard to review):
def complex_calculation(a,b,c):
    result=a*b+c if a>b else a+b*c
    return result if result>0 else 0

Команда: "Auto-format before review"

After (easy to review logic):
def complex_calculation(a, b, c):
    if a > b:
        result = a * b + c
    else:
        result = a + b * c
    
    return result if result > 0 else 0

Reviewer теперь фокусируется на логике, не на форматировании
```

**Use Case 3: Миграция legacy кода**
```
Ситуация: Старый код с плохим форматированием

Legacy JavaScript (2010-style):
var UserController=function(){
  this.users=[];
  this.addUser=function(name){this.users.push(name)}
  this.getUsers=function(){return this.users}
}

Команда: "Форматируй и модернизируй в ES6 style"

Claude:
class UserController {
  constructor() {
    this.users = [];
  }

  addUser(name) {
    this.users.push(name);
  }

  getUsers() {
    return this.users;
  }
}

Изменения:
- ✓ Конвертировал в ES6 class
- ✓ Добавил proper spacing
- ✓ Разделил методы
```

**Use Case 4: Мультиязычный проект**
```
Ситуация: Fullstack проект (Python backend, TypeScript frontend, Go microservices)

Команда: "Форматируй все файлы в проекте"

Claude:
Scanning project...
Found:
- 45 Python files
- 120 TypeScript files
- 23 Go files

Formatting...
✓ Python: применён Black
✓ TypeScript: применён Prettier
✓ Go: применён gofmt

Summary:
- 188 files formatted
- 0 errors
- 1,247 lines changed
```

### Технические требования

**MCP серверы:**
- `mcp-filesystem` — чтение/запись файлов

**Language formatters (установлены локально):**
```bash
# Python
pip install black

# JavaScript/TypeScript
npm install -g prettier

# Go
# gofmt встроен в Go

# Rust
# rustfmt встроен в Rust

# C/C++
apt-get install clang-format
```

**Базовая архитектура:**
```python
class UniversalCodeFormatter:
    def __init__(self):
        self.formatters = {
            'python': self.format_python,
            'javascript': self.format_javascript,
            'typescript': self.format_javascript,  # Prettier handles both
            'go': self.format_go,
            'rust': self.format_rust,
            'cpp': self.format_cpp,
            'java': self.format_java,
        }
    
    def format_code(self, code, language=None, explain=False):
        """
        Форматирует код
        """
        # Определяем язык если не указан
        if language is None:
            language = self.detect_language(code)
        
        # Получаем соответствующий formatter
        formatter = self.formatters.get(language)
        if not formatter:
            return f"Unsupported language: {language}"
        
        # Форматируем
        formatted_code = formatter(code)
        
        # Если нужны объяснения
        if explain:
            changes = self.explain_changes(code, formatted_code, language)
            return {
                'code': formatted_code,
                'changes': changes
            }
        
        return formatted_code
    
    def detect_language(self, code):
        """
        Определяет язык программирования
        """
        # Claude может определить язык по синтаксису
        prompt = f"""
        What programming language is this code?
        Return only the language name (python, javascript, go, rust, etc.)
        
        Code:
        {code[:500]}  # Первые 500 символов достаточно
        """
        
        language = claude_api(prompt).strip().lower()
        return language
    
    def format_python(self, code):
        """
        Форматирование Python кода
        """
        import black
        
        try:
            formatted = black.format_str(code, mode=black.Mode())
            return formatted
        except Exception as e:
            return f"Error formatting Python: {e}"
    
    def format_javascript(self, code):
        """
        Форматирование JavaScript/TypeScript
        """
        import subprocess
        import tempfile
        
        # Создаём временный файл
        with tempfile.NamedTemporaryFile(mode='w', suffix='.js', delete=False) as f:
            f.write(code)
            temp_file = f.name
        
        # Запускаем Prettier
        subprocess.run(['prettier', '--write', temp_file])
        
        # Читаем результат
        with open(temp_file, 'r') as f:
            formatted = f.read()
        
        os.remove(temp_file)
        return formatted
    
    def format_go(self, code):
        """
        Форматирование Go кода
        """
        import subprocess
        
        # gofmt читает из stdin
        result = subprocess.run(
            ['gofmt'],
            input=code,
            capture_output=True,
            text=True
        )
        
        return result.stdout
    
    def explain_changes(self, original, formatted, language):
        """
        Claude объясняет что изменилось
        """
        prompt = f"""
        Explain the formatting changes made to this {language} code.
        
        Original:
        ```
        {original}
        ```
        
        Formatted:
        ```
        {formatted}
        ```
        
        Provide:
        1. List of main changes
        2. Reason for each change (which style guide rule)
        3. Number of lines affected
        """
        
        explanation = claude_api(prompt)
        return explanation
```

**Определение project style:**
```python
def detect_project_style(project_path):
    """
    Ищет конфигурационные файлы style в проекте
    """
    style_files = {
        'python': ['.flake8', 'setup.cfg', 'pyproject.toml'],
        'javascript': ['.prettierrc', '.prettierrc.json', 'prettier.config.js'],
        'typescript': ['tsconfig.json', '.prettierrc'],
        'go': ['.editorconfig'],
        'rust': ['rustfmt.toml', '.rustfmt.toml'],
    }
    
    found_configs = {}
    
    for language, config_files in style_files.items():
        for config_file in config_files:
            config_path = os.path.join(project_path, config_file)
            if os.path.exists(config_path):
                found_configs[language] = config_path
                break
    
    return found_configs
```

### Пример интерфейса

```
Universal Code Formatter
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Input:
[Paste code] or [Choose file...]

Auto-detected: Python

Options:
  (•) Auto-detect style (use project config if available)
  ( ) Use standard style (PEP 8 / Prettier defaults)
  ( ) Custom config: [Browse...]

  ☑ Explain changes
  ☐ Fix common issues (unused imports, etc.)
  ☐ Add type hints (Python/TypeScript)
  ☐ Sort imports

Preview:
┌─────────────────────────────────────────────────┐
│ BEFORE                  │ AFTER                  │
├─────────────────────────┼────────────────────────┤
│ def calc(x,y):          │ def calc(x, y):        │
│     return x+y          │     return x + y       │
│                         │                        │
└─────────────────────────┴────────────────────────┘

Changes:
✓ Added spaces around operators (2 places)
✓ Added spaces after commas (1 place)

[Apply] [Copy result] [Save]
```

### Расширенные возможности

**1. Batch formatting:**
```bash
Команда: "Форматируй все Python файлы в src/"

Scanning src/...
Found 45 Python files

Formatting:
✓ src/main.py (15 changes)
✓ src/utils.py (3 changes)
✓ src/models/user.py (8 changes)
...

Summary:
- 45 files processed
- 234 lines changed
- 0 errors

Git diff available: git diff
```

**2. Pre-commit hook integration:**
```python
# .git/hooks/pre-commit (generated by Claude)

#!/bin/bash
# Auto-format code before commit

# Get staged Python files
python_files=$(git diff --cached --name-only --diff-filter=ACM | grep '.py$')

if [ ! -z "$python_files" ]; then
    echo "Formatting Python files..."
    python -m black $python_files
    git add $python_files
fi

# Get staged JS files
js_files=$(git diff --cached --name-only --diff-filter=ACM | grep '.js$\|.ts$')

if [ ! -z "$js_files" ]; then
    echo "Formatting JavaScript files..."
    prettier --write $js_files
    git add $js_files
fi
```

**3. Code quality improvements:**
```
Команда: "Форматируй и улучши качество кода"

Claude не только форматирует, но и:

Original:
def process(data):
    result = []
    for item in data:
        result.append(item * 2)
    return result

Improved:
def process(data: list[int]) -> list[int]:
    """Double each item in the list."""
    return [item * 2 for item in data]

Improvements:
✓ Добавлены type hints
✓ Добавлен docstring
✓ Использован list comprehension (более pythonic)
```

---

## Skill #14: JSON/YAML/XML Converter
**Уровень сложности:** 🟡 Средний  
**Приоритет реализации:** 🟡 Средний  
**Категория:** Базовое форматирование

### Описание
Конвертация между форматами данных (JSON, YAML, XML, TOML) с сохранением комментариев, валидацией и умным форматированием.

### Проблема которую решает
- Нужно конвертировать config файлы между форматами
- API возвращает XML, а нужен JSON
- YAML конфиг нужен в JSON для API
- Потеря комментариев при конвертации
- Сложная вложенность — трудно конвертировать вручную

### Существующие решения и их ограничения

**Online converters (json2yaml.com, etc.):**
✅ Простые в использовании
❌ Теряют комментарии
❌ Базовая валидация
❌ Загрузка данных на сторонний сервер

**yq (командная строка):**
```bash
yq eval -o=json config.yaml > config.json
```
✅ Мощный инструмент
❌ Нужно знать синтаксис
❌ Комментарии теряются

**Python scripts:**
```python
import json
import yaml

with open('config.yaml') as f:
    data = yaml.safe_load(f)

with open('config.json', 'w') as f:
    json.dump(data, f, indent=2)
```
❌ Нужны навыки программирования
❌ Теряются комментарии
❌ Нет валидации

### Как Claude улучшает это

**Сохранение комментариев:**

**Input YAML:**
```yaml
# Database configuration
database:
  host: localhost  # Change in production
  port: 5432
  # User credentials
  username: admin
  password: secret  # TODO: use environment variable
```

**Традиционный конвертер → JSON:**
```json
{
  "database": {
    "host": "localhost",
    "port": 5432,
    "username": "admin",
    "password": "secret"
  }
}
```
❌ Все комментарии потеряны

**Claude → JSON with comments (JSON5/JSONC):**
```json
{
  // Database configuration
  "database": {
    "host": "localhost",  // Change in production
    "port": 5432,
    // User credentials
    "username": "admin",
    "password": "secret"  // TODO: use environment variable
  }
}
```
✓ Комментарии сохранены

**Умная валидация:**

```
Input (invalid JSON):
{
  "name": "John",
  "age": 25,  <- trailing comma (invalid in JSON)
}

Команда: "Конвертируй в YAML и исправь ошибки"

Claude:
⚠️ Исправлены ошибки:
- Удалена trailing comma после "age": 25

Output YAML:
name: John
age: 25
```

**Интеллектуальное форматирование:**

**XML → JSON (с упрощением):**
```xml
<users>
  <user>
    <id>1</id>
    <name>John</name>
    <email>john@email.com</email>
  </user>
  <user>
    <id>2</id>
    <name>Jane</name>
    <email>jane@email.com</email>
  </user>
</users>
```

**Простая конвертация (дословная):**
```json
{
  "users": {
    "user": [
      {
        "id": "1",
        "name": "John",
        "email": "john@email.com"
      },
      {
        "id": "2",
        "name": "Jane",
        "email": "jane@email.com"
      }
    ]
  }
}
```

**Claude (умная упрощение):**
```json
{
  "users": [
    {
      "id": 1,
      "name": "John",
      "email": "john@email.com"
    },
    {
      "id": 2,
      "name": "Jane",
      "email": "jane@email.com"
    }
  ]
}
```
✓ Убрал лишний уровень вложенности (users.user → users)
✓ Преобразовал "1" → 1 (числа)

### Конкретные Use Cases

**Use Case 1: DevOps — конвертация конфигов**
```
Ситуация: Kubernetes config в JSON, нужен YAML

Input JSON:
{
  "apiVersion": "v1",
  "kind": "Service",
  "metadata": {
    "name": "my-service"
  },
  "spec": {
    "selector": {
      "app": "MyApp"
    },
    "ports": [
      {
        "protocol": "TCP",
        "port": 80,
        "targetPort": 9376
      }
    ]
  }
}

Команда: "Конвертируй в Kubernetes YAML"

Claude:
apiVersion: v1
kind: Service
metadata:
  name: my-service
spec:
  selector:
    app: MyApp
  ports:
    - protocol: TCP
      port: 80
      targetPort: 9376
```

**Use Case 2: API Integration — XML response → JSON**
```
Ситуация: Legacy API возвращает XML, современный frontend ждёт JSON

XML Response:
<?xml version="1.0"?>
<product>
  <id>12345</id>
  <name>Laptop</name>
  <price currency="USD">999.99</price>
  <inStock>true</inStock>
</product>

Команда: "Конвертируй в JSON, сохрани атрибуты"

Claude:
{
  "product": {
    "id": 12345,
    "name": "Laptop",
    "price": {
      "value": 999.99,
      "currency": "USD"
    },
    "inStock": true
  }
}

✓ Атрибут currency сохранён как вложенный объект
✓ Типы данных конвертированы (12345 как число, true как boolean)
```

**Use Case 3: Configuration management**
```
Ситуация: Разные environments используют разные форматы

development.yaml:
database:
  host: localhost
  port: 5432

production.json нужен для deployment:
{
  "database": {
    "host": "prod-db.company.com",
    "port": 5432
  }
}

Команда: "Конвертируй development.yaml в production.json,
         замени host на prod-db.company.com"

Claude:
{
  "database": {
    "host": "prod-db.company.com",
    "port": 5432
  }
}

✓ Конвертирован
✓ Host изменён
✓ Валидация пройдена
```

**Use Case 4: Data migration**
```
Ситуация: Миграция с XML-based storage на JSON

XML (100 записей):
<products>
  <product id="1">...</product>
  <product id="2">...</product>
  ...
</products>

Команда: "Batch convert all XML files to JSON"

Claude:
Processing...
✓ products.xml → products.json (100 records)
✓ users.xml → users.json (500 records)
✓ orders.xml → orders.json (1,200 records)

Summary:
- 3 files converted
- 1,800 total records
- 0 errors
- Validation: passed
```

### Технические требования

**Python библиотеки:**
```python
import json
import yaml
import xml.etree.ElementTree as ET
import toml
from ruamel.yaml import YAML  # Для сохранения комментариев
```

**Базовая архитектура:**
```python
class DataFormatConverter:
    def __init__(self):
        self.converters = {
            ('json', 'yaml'): self.json_to_yaml,
            ('yaml', 'json'): self.yaml_to_json,
            ('xml', 'json'): self.xml_to_json,
            ('json', 'xml'): self.json_to_xml,
            ('toml', 'yaml'): self.toml_to_yaml,
            ('yaml', 'toml'): self.yaml_to_toml,
        }
    
    def convert(self, input_data, from_format, to_format, options=None):
        """
        Главная функция конвертации
        """
        options = options or {}
        
        # Получаем converter
        converter_key = (from_format.lower(), to_format.lower())
        converter = self.converters.get(converter_key)
        
        if not converter:
            return f"Conversion from {from_format} to {to_format} not supported"
        
        # Валидация входных данных
        validation_result = self.validate_format(input_data, from_format)
        if not validation_result['valid']:
            return f"Invalid {from_format}: {validation_result['error']}"
        
        # Конвертация
        output = converter(input_data, options)
        
        # Валидация выходных данных
        validation_result = self.validate_format(output, to_format)
        if not validation_result['valid']:
            return f"Conversion produced invalid {to_format}: {validation_result['error']}"
        
        return output
    
    def json_to_yaml(self, json_data, options):
        """
        JSON → YAML
        """
        # Парсим JSON
        data = json.loads(json_data)
        
        # Если нужно сохранить комментарии
        if options.get('preserve_comments'):
            yaml_processor = YAML()
            yaml_processor.preserve_quotes = True
            
            import io
            output = io.StringIO()
            yaml_processor.dump(data, output)
            return output.getvalue()
        else:
            # Обычная конвертация
            return yaml.dump(data, default_flow_style=False, sort_keys=False)
    
    def yaml_to_json(self, yaml_data, options):
        """
        YAML → JSON
        """
        # Парсим YAML
        data = yaml.safe_load(yaml_data)
        
        # Форматируем JSON
        indent = options.get('indent', 2)
        return json.dumps(data, indent=indent, ensure_ascii=False)
    
    def xml_to_json(self, xml_data, options):
        """
        XML → JSON
        """
        # Парсим XML
        root = ET.fromstring(xml_data)
        
        # Конвертируем в dict
        def xml_to_dict(element):
            result = {}
            
            # Атрибуты
            if element.attrib:
                result['@attributes'] = element.attrib
            
            # Текст
            if element.text and element.text.strip():
                # Пытаемся преобразовать в правильный тип
                text = element.text.strip()
                if text.isdigit():
                    result['#text'] = int(text)
                elif text.replace('.', '').isdigit():
                    result['#text'] = float(text)
                elif text.lower() in ('true', 'false'):
                    result['#text'] = text.lower() == 'true'
                else:
                    result['#text'] = text
            
            # Дочерние элементы
            for child in element:
                child_data = xml_to_dict(child)
                
                if child.tag in result:
                    # Если уже есть, делаем массив
                    if not isinstance(result[child.tag], list):
                        result[child.tag] = [result[child.tag]]
                    result[child.tag].append(child_data)
                else:
                    result[child.tag] = child_data
            
            # Упрощение если только текст
            if len(result) == 1 and '#text' in result:
                return result['#text']
            
            return result
        
        data = {root.tag: xml_to_dict(root)}
        
        # Claude может упростить структуру
        if options.get('simplify'):
            data = claude_simplify_structure(data)
        
        return json.dumps(data, indent=2)
    
    def validate_format(self, data, format_name):
        """
        Валидация данных
        """
        try:
            if format_name == 'json':
                json.loads(data)
            elif format_name == 'yaml':
                yaml.safe_load(data)
            elif format_name == 'xml':
                ET.fromstring(data)
            elif format_name == 'toml':
                toml.loads(data)
            
            return {'valid': True}
        
        except Exception as e:
            return {'valid': False, 'error': str(e)}
```

**Claude упрощение структуры:**
```python
def claude_simplify_structure(data):
    """
    Claude анализирует структуру и упрощает её
    """
    prompt = f"""
    Simplify this data structure by removing unnecessary nesting.
    
    Rules:
    1. If an object has only one key that is a list, unwrap it
    2. Convert string numbers to actual numbers
    3. Remove redundant wrapper objects
    
    Data:
    {json.dumps(data, indent=2)}
    
    Return simplified JSON.
    """
    
    simplified_json = claude_api(prompt)
    return json.loads(simplified_json)
```

### Пример интерфейса

```
JSON/YAML/XML Converter
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

From format: [JSON ▼]
To format:   [YAML ▼]

Input:
┌────────────────────────────────────────────────┐
│ {                                              │
│   "database": {                                │
│     "host": "localhost",                       │
│     "port": 5432                               │
│   }                                            │
│ }                                              │
└────────────────────────────────────────────────┘

Options:
  ☑ Preserve comments (if possible)
  ☑ Validate input/output
  ☑ Pretty-print output
  ☐ Simplify structure (remove unnecessary nesting)
  ☐ Convert string numbers to actual numbers
  
[Convert]

Output:
┌────────────────────────────────────────────────┐
│ database:                                      │
│   host: localhost                              │
│   port: 5432                                   │
└────────────────────────────────────────────────┘

✓ Validation passed
✓ Conversion successful

[Copy] [Save as...] [Convert another]
```

### Расширенные возможности

**1. Schema validation:**
```
Команда: "Конвертируй и валидируй по JSON Schema"

JSON Schema:
{
  "type": "object",
  "required": ["name", "age"],
  "properties": {
    "name": {"type": "string"},
    "age": {"type": "number", "minimum": 0}
  }
}

Input YAML:
name: John
age: 25

Output JSON:
{
  "name": "John",
  "age": 25
}

✓ Validation passed: matches schema
```

**2. Template substitution:**
```
Команда: "Конвертируй и подставь переменные"

Template YAML:
database:
  host: ${DB_HOST}
  port: ${DB_PORT}
  
Variables:
DB_HOST=prod-db.company.com
DB_PORT=5432

Output JSON:
{
  "database": {
    "host": "prod-db.company.com",
    "port": 5432
  }
}
```

**3. Diff visualization:**
```
Команда: "Покажи различия между двумя конфигами"

config_old.yaml:
database:
  host: localhost
  port: 5432

config_new.json:
{
  "database": {
    "host": "prod-db.com",
    "port": 5432,
    "ssl": true
  }
}

Claude:
Differences:
+ database.ssl: true (added)
~ database.host: localhost → prod-db.com (changed)
= database.port: 5432 (unchanged)
```

---

## Skill #15: Clean Paste
**Уровень сложности:** 🟡 Средний  
**Приоритет реализации:** 🟡 Средний  
**Категория:** Базовое форматирование

### Описание
Интеллектуальная очистка текста при вставке с сохранением нужного форматирования и удалением мусора из PDF, Word, веб-страниц.

### Проблема которую решает
- Копируешь текст из PDF → получаешь переносы строк в середине предложений
- Вставляешь из Word → тянутся ненужные стили и форматирование
- Копируешь с веб-страницы → получаешь HTML теги, рекламу, номера строк кода
- Вставляешь email → сохраняются цитаты на цитатах (>>>>>>>)
- Нужно вставить только plain text, но сохранить параграфы

### Существующие решения и их ограничения

**Paste as plain text (Ctrl+Shift+V):**
```
Копируешь из Word:
"Important: This is formatted text."

Paste as plain text:
"Important: This is formatted text."
```
✅ Удаляет форматирование
❌ Теряет всё: и нужное (bold), и ненужное (fonts, colors)
❌ Не исправляет переносы строк из PDF
❌ Не чистит HTML мусор

**PureText (Windows app):**
✅ Горячая клавиша для paste без форматирования
❌ Просто удаляет всё, без умной обработки

**Word — "Keep text only":**
✅ Опция при paste
❌ Всё равно оставляет лишние пробелы, переносы
❌ Не универсально (только в Word)

### Как Claude улучшает это

**Умная очистка с сохранением структуры:**

**Пример 1: PDF text (с артефактами OCR)**

**Input (скопировано из PDF):**
```
Introduction  to  Machine  Learning

Machine   learning  is  a  subset  of  artificial
intelligence that focuses on  the  development of
algorithms.

Key   Concepts:
•  Supervised Learning
•  Unsupervised   Learning
```

**Традиционная paste:** Сохраняет все лишние пробелы и разрывы

**Claude Clean Paste:**
```
Introduction to Machine Learning

Machine learning is a subset of artificial intelligence that focuses on the development of algorithms.

Key Concepts:
• Supervised Learning
• Unsupervised Learning
```

Исправлено:
- ✓ Убраны лишние пробелы
- ✓ Объединены разорванные предложения
- ✓ Сохранены параграфы
- ✓ Сохранены bullet points

**Пример 2: Копирование кода с сайта**

**Input (с GitHub):**
```html
<div class="highlight">
  <pre><code class="language-python">
    1 | def hello():
    2 |     print("Hello World")
    3 |
  </code></pre>
</div>
```

**Традиционная paste в IDE:** Вставляется весь HTML

**Claude Clean Paste:**
```python
def hello():
    print("Hello World")
```

Очищено:
- ✓ Убраны HTML теги
- ✓ Убраны номера строк
- ✓ Сохранены отступы
- ✓ Готово для вставки в код

**Пример 3: Email thread (множественные цитаты)**

**Input:**
```
Hi John,

That sounds good.

> On Jan 27, John wrote:
> > On Jan 26, Jane wrote:
> > > What time works?
> >
> > How about 3pm?
>
> 3pm works for me.
```

**Claude Clean Paste (опция: "remove email quotes"):**
```
Hi John,

That sounds good.
```

Или **keep only last message:**
```
Hi John,

That sounds good.

Previous context:
- Jane asked about time
- John suggested 3pm
```

### Конкретные Use Cases

**Use Case 1: Студент готовит конспект**
```
Ситуация: Копирует из учебника (PDF) для своих заметок

PDF text:
"""
The  Pythagorean  theorem   states  that   in   a
right-angled   triangle,  the  square  of  the
hypotenuse  is   equal  to   the   sum  of   the
squares   of   the   other   two  sides:
                                     2      2      2
                                    a   +  b   =  c
"""

Команда: "Clean paste для заметок"

Claude:
The Pythagorean theorem states that in a right-angled triangle, the square of the hypotenuse is equal to the sum of the squares of the other two sides:

a² + b² = c²

✓ Объединил разорванные строки
✓ Исправил формулу (2 → ²)
✓ Убрал лишние пробелы
```

**Use Case 2: Программист копирует код из StackOverflow**
```
Input (HTML со страницы):
<div class="answer">
  <p>You can do this:</p>
  <pre><code>// Solution
function example() {
  return true;
}</code></pre>
  <p>Upvotes: 42</p>
</div>

Команда: "Clean paste code only"

Claude:
// Solution
function example() {
  return true;
}

✓ Извлечён только код
✓ Убран HTML
✓ Убран текст "Upvotes: 42"
```

**Use Case 3: Копирайтер чистит текст для блога**
```
Input (скопировано из Word с форматированием):
<p style="font-family: Times New Roman; font-size: 12pt; margin: 0;">
  <strong style="color: red;">Important:</strong> 
  <em>This is</em> the <u>main</u> point.
</p>

Команда: "Clean paste для Markdown блога"

Claude:
**Important:** *This is* the main point.

✓ Конвертировал в Markdown
✓ Убрал inline styles
✓ Сохранил смысловое форматирование (bold, italic)
```

**Use Case 4: Researcher извлекает цитаты из статей**
```
Input (academic PDF):
"""
As Smith et al. (2020) noted, "the 
results were significant" (p. 42). This 
finding   was   later   confirmed   by 
Johnson (2021).
"""

Команда: "Clean paste academic quote"

Claude:
As Smith et al. (2020) noted, "the results were significant" (p. 42). This finding was later confirmed by Johnson (2021).

✓ Объединены строки
✓ Сохранены citations в правильном формате
✓ Убраны артефакты PDF
```

### Технические требования

**MCP серверы:**
- `mcp-clipboard` — доступ к системному clipboard

**Python библиотеки:**
```python
import re
from bs4 import BeautifulSoup
import pyperclip
```

**Базовая архитектура:**
```python
class CleanPaste:
    def __init__(self):
        self.cleaners = {
            'pdf_artifacts': self.clean_pdf_artifacts,
            'html_tags': self.clean_html,
            'email_quotes': self.clean_email_quotes,
            'extra_whitespace': self.clean_whitespace,
            'line_numbers': self.clean_line_numbers,
        }
    
    def clean_clipboard(self, cleaning_options=None):
        """
        Очищает текст из clipboard
        """
        # Получаем текст из clipboard
        raw_text = pyperclip.paste()
        
        # Определяем тип содержимого
        content_type = self.detect_content_type(raw_text)
        
        # Применяем соответствующие cleaners
        cleaned_text = raw_text
        
        if content_type == 'pdf':
            cleaned_text = self.clean_pdf_artifacts(cleaned_text)
        elif content_type == 'html':
            cleaned_text = self.clean_html(cleaned_text)
        elif content_type == 'email':
            cleaned_text = self.clean_email_quotes(cleaned_text)
        elif content_type == 'code_snippet':
            cleaned_text = self.clean_code_snippet(cleaned_text)
        
        # Общая очистка (всегда)
        cleaned_text = self.clean_whitespace(cleaned_text)
        
        # Claude может дополнительно проанализировать
        if cleaning_options and cleaning_options.get('smart_clean'):
            cleaned_text = claude_smart_clean(cleaned_text, content_type)
        
        return cleaned_text
    
    def detect_content_type(self, text):
        """
        Определяет тип содержимого
        """
        if '<' in text and '>' in text:
            return 'html'
        elif re.search(r'^\s*\d+\s*\|', text, re.MULTILINE):
            return 'code_snippet'  # С номерами строк
        elif re.search(r'^>+\s', text, re.MULTILINE):
            return 'email'
        elif re.search(r'\w+\s{3,}\w+', text):
            return 'pdf'  # Много пробелов = вероятно PDF
        else:
            return 'plain_text'
    
    def clean_pdf_artifacts(self, text):
        """
        Очистка артефактов из PDF
        """
        # Объединяем разорванные строки
        # Правило: если строка не заканчивается на . ! ? : и следующая начинается с lowercase
        lines = text.split('\n')
        cleaned_lines = []
        
        i = 0
        while i < len(lines):
            line = lines[i].strip()
            
            # Если это не конец предложения и следующая строка не начинается с заглавной
            if i + 1 < len(lines):
                next_line = lines[i + 1].strip()
                
                # Проверяем нужно ли объединить
                if (line and not line[-1] in '.!?:' and 
                    next_line and next_line[0].islower()):
                    # Объединяем
                    line = line + ' ' + next_line
                    i += 2
                    cleaned_lines.append(line)
                    continue
            
            cleaned_lines.append(line)
            i += 1
        
        # Убираем лишние пробелы внутри строк
        cleaned_lines = [re.sub(r'\s{2,}', ' ', line) for line in cleaned_lines]
        
        return '\n'.join(cleaned_lines)
    
    def clean_html(self, text):
        """
        Очистка HTML тегов
        """
        soup = BeautifulSoup(text, 'html.parser')
        
        # Убираем script и style теги
        for tag in soup(['script', 'style', 'nav', 'footer', 'header']):
            tag.decompose()
        
        # Получаем только текст
        text = soup.get_text()
        
        # Убираем лишние пустые строки
        text = re.sub(r'\n{3,}', '\n\n', text)
        
        return text.strip()
    
    def clean_email_quotes(self, text):
        """
        Очистка email цитат
        """
        lines = text.split('\n')
        cleaned_lines = []
        
        for line in lines:
            # Удаляем строки начинающиеся с > (цитаты)
            if not re.match(r'^>+\s', line):
                cleaned_lines.append(line)
        
        return '\n'.join(cleaned_lines)
    
    def clean_code_snippet(self, text):
        """
        Очистка кода (убирает номера строк)
        """
        lines = text.split('\n')
        cleaned_lines = []
        
        for line in lines:
            # Убираем номера строк в формате: "  1 | code"
            cleaned_line = re.sub(r'^\s*\d+\s*\|\s*', '', line)
            cleaned_lines.append(cleaned_line)
        
        return '\n'.join(cleaned_lines)
    
    def clean_whitespace(self, text):
        """
        Общая очистка пробелов
        """
        # Убираем trailing whitespace
        lines = [line.rstrip() for line in text.split('\n')]
        
        # Убираем множественные пустые строки
        cleaned_lines = []
        prev_empty = False
        
        for line in lines:
            if line.strip():
                cleaned_lines.append(line)
                prev_empty = False
            else:
                if not prev_empty:
                    cleaned_lines.append('')
                prev_empty = True
        
        return '\n'.join(cleaned_lines)
```

**Claude smart cleaning:**
```python
def claude_smart_clean(text, content_type):
    """
    Claude дополнительно анализирует и чистит текст
    """
    prompt = f"""
    Clean this {content_type} text while preserving meaning and structure.
    
    Rules:
    - Fix broken sentences
    - Remove artifacts and noise
    - Preserve intentional formatting (lists, paragraphs)
    - Fix common OCR errors (l → 1 in numbers, O → 0, etc.)
    
    Text:
    {text}
    
    Return cleaned text only.
    """
    
    cleaned = claude_api(prompt)
    return cleaned
```

### Пример интерфейса

```
Clean Paste
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Clipboard content detected:
  Type: PDF text with artifacts
  Size: 1,245 characters

Cleaning options:
  ☑ Fix broken lines
  ☑ Remove extra whitespace
  ☑ Fix common OCR errors
  ☐ Remove all formatting
  ☐ Convert to Markdown

Preview:
┌────────────────────────────────────────────────┐
│ BEFORE                  │ AFTER                 │
├────────────────────────┼────────────────────────┤
│ The  results  were     │ The results were       │
│ signifi-               │ significant and showed │
│ cant and  showed       │ improvement.           │
│ improve-               │                        │
│ ment.                  │                        │
└────────────────────────┴────────────────────────┘

[Paste clean] [Copy to clipboard] [Configure...]

Keyboard shortcut: Ctrl+Shift+Alt+V
```

### Расширенные возможности

**1. Auto-detect and suggest:**
```
Вставляешь текст из PDF

Claude:
⚠️ Обнаружены артефакты PDF:
  - 15 разорванных предложений
  - 45 лишних пробелов
  - 3 неправильных переноса слов

Очистить автоматически? [Yes] [No] [Show details]
```

**2. Custom cleaning rules:**
```yaml
# cleaning_rules.yaml

pdf:
  join_broken_lines: true
  fix_hyphenation: true
  remove_headers_footers: true

html:
  strip_tags: true
  preserve_links: true
  remove_scripts: true

code:
  remove_line_numbers: true
  preserve_indentation: true
  detect_language: true
```

**3. Batch cleaning:**
```
Команда: "Clean all text files in this folder"

Processing...
✓ document1.txt (cleaned PDF artifacts)
✓ document2.txt (cleaned HTML)
✓ notes.txt (cleaned extra whitespace)

Summary: 3 files processed, 1,234 cleaning operations
```

---

### КАТЕГОРИЯ 1.4: ПРОСТЫЕ КОНВЕРТАЦИИ

## Skill #16: Unit Converter Pro
**Уровень сложности:** 🟢 Базовый  
**Приоритет реализации:** 🟢 Низкий  
**Категория:** Простые конвертации

### Описание
Универсальный конвертер единиц измерения с пониманием контекста, автоопределением единиц и конвертацией прямо в тексте.

### Проблема которую решает
- Нужно конвертировать между метрической и имперской системой
- Рецепты в cups/ounces, а нужны граммы/миллилитры
- Технические specs в дюймах, нужны миллиметры
- Температура по Фаренгейту, нужна в Цельсиях
- Разные валюты, временные зоны, скорости

### Существующие решения и их ограничения

**Google converter:**
```
Search: "10 miles to km"
Result: 16.09 km
```
✅ Быстро и точно
❌ Нужно переключаться в браузер
❌ По одной конвертации
❌ Не работает в документах

**Online calculators (unitconverters.net):**
✅ Много категорий
❌ Медленный интерфейс
❌ Не контекстная конвертация

**Встроенные OS калькуляторы:**
✅ Доступно локально
❌ Ограниченный набор единиц
❌ Нет контекстного понимания

### Как Claude улучшает это

**Контекстная конвертация в тексте:**

**Input:**
```
"The car is traveling at 60 mph on the highway. 
The speed limit is 100 km/h."
```

**Команда:** "Приведи все скорости к км/ч"

**Claude:**
```
"The car is traveling at 97 km/h on the highway.
The speed limit is 100 km/h."
```
✓ Автоматически нашёл 60 mph
✓ Конвертировал только то что нужно
✓ Сохранил контекст

**Понимание неявных единиц:**

```
User: "Сколько будет 5'10" в сантиметрах?"

Claude: "5 футов 10 дюймов = 177.8 см"
```

Claude понимает:
- ' = футы
- " = дюймы
- Автоматически переводит в метрическую систему

**Умные рекомендации:**

```
User: "Конвертируй 2.5 cups flour в граммы"

Claude: "2.5 cups flour ≈ 310 grams

Примечание: Точный вес зависит от типа муки:
- All-purpose flour: ~310g
- Bread flour: ~320g
- Cake flour: ~285g

Я использовал all-purpose flour."
```

### Конкретные Use Cases

**Use Case 1: Готовка по американским рецептам**
```
Recipe (US):
- 2 cups flour
- 1 cup sugar
- 1/2 cup butter
- 3/4 tsp salt
- 350°F oven

Команда: "Конвертируй в метрические единицы"

Claude:
- 250 g муки
- 200 g сахара
- 115 g сливочного масла
- 4 g соли
- 175°C духовка

Бонус: "Примечание: 1 cup = 240ml (жидкости) или ~125g (муки)"
```

**Use Case 2: Международная торговля**
```
Product specs (US):
- Weight: 5.5 lbs
- Dimensions: 12" x 8" x 6"
- Capacity: 2 gallons

Команда: "Конвертируй для европейского рынка"

Claude:
- Вес: 2.5 кг
- Размеры: 30.5 см × 20.3 см × 15.2 см
- Объём: 7.6 литра
```

**Use Case 3: Строительство и DIY**
```
Material list:
- 2x4 lumber: 8 feet
- Screws: 1.5 inch
- Plywood: 4'x8' sheet

Команда: "Конвертируй в метрические для покупки в Европе"

Claude:
- Брус 50×100 мм: 2.44 метра
- Саморезы: 38 мм
- Фанера: лист 122×244 см

Совет: "2×4 на самом деле 1.5"×3.5" (38×89 мм), 
       ближайший европейский размер: 50×100 мм"
```

**Use Case 4: Фитнес и здоровье**
```
Workout stats:
- Distance: 3.2 miles
- Speed: 7 mph
- Burned: 450 cal

Команда: "Конвертируй в метрические"

Claude:
- Дистанция: 5.15 км
- Скорость: 11.3 км/ч
- Сожжено: 1,884 кДж (или 450 ккал)
```

### Технические требования

**Python библиотека:**
```python
from pint import UnitRegistry
```

**Базовая архитектура:**
```python
class UnitConverterPro:
    def __init__(self):
        self.ureg = UnitRegistry()
        
        # Custom units
        self.ureg.define('cup = 236.588 * milliliter')
        self.ureg.define('tablespoon = 14.787 * milliliter')
        self.ureg.define('teaspoon = 4.929 * milliliter')
    
    def convert(self, value, from_unit, to_unit):
        """
        Базовая конвертация
        """
        quantity = value * self.ureg(from_unit)
        result = quantity.to(to_unit)
        return result.magnitude
    
    def convert_in_text(self, text, target_system='metric'):
        """
        Конвертирует единицы прямо в тексте
        """
        # Claude ищет все упоминания единиц
        matches = self.find_units_in_text(text)
        
        # Конвертирует каждое
        for match in matches:
            original = match['text']
            value = match['value']
            unit = match['unit']
            
            # Определяем целевую единицу
            target_unit = self.get_target_unit(unit, target_system)
            
            # Конвертируем
            converted_value = self.convert(value, unit, target_unit)
            
            # Заменяем в тексте
            replacement = f"{converted_value:.1f} {target_unit}"
            text = text.replace(original, replacement)
        
        return text
    
    def find_units_in_text(self, text):
        """
        Claude ищет упоминания единиц измерения
        """
        prompt = f"""
        Find all measurements with units in this text.
        
        Text: {text}
        
        Return JSON array:
        [
          {{"text": "60 mph", "value": 60, "unit": "mph"}},
          {{"text": "100 km/h", "value": 100, "unit": "km/h"}}
        ]
        """
        
        matches_json = claude_api(prompt)
        return json.loads(matches_json)
    
    def get_target_unit(self, source_unit, target_system):
        """
        Определяет в какую единицу конвертировать
        """
        conversion_map = {
            'metric': {
                'mph': 'km/h',
                'miles': 'km',
                'feet': 'm',
                'inches': 'cm',
                'pounds': 'kg',
                'ounces': 'g',
                'fahrenheit': 'celsius',
                'gallons': 'liters',
                'cups': 'ml',
            },
            'imperial': {
                'km/h': 'mph',
                'km': 'miles',
                'm': 'feet',
                'cm': 'inches',
                'kg': 'pounds',
                'g': 'ounces',
                'celsius': 'fahrenheit',
                'liters': 'gallons',
                'ml': 'cups',
            }
        }
        
        return conversion_map[target_system].get(source_unit, source_unit)
```

### Пример интерфейса

```
Unit Converter Pro
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Quick convert:
[10] [miles ▼] = [16.09] [km ▼]

Or paste text:
┌────────────────────────────────────────────────┐
│ The car is traveling at 60 mph.                │
│ Temperature: 72°F                              │
│ Weight: 150 lbs                                │
└────────────────────────────────────────────────┘

Target system: (•) Metric  ( ) Imperial

[Convert in text]

Result:
┌────────────────────────────────────────────────┐
│ The car is traveling at 97 km/h.               │
│ Temperature: 22°C                              │
│ Weight: 68 kg                                  │
└────────────────────────────────────────────────┘

Common conversions:
• 1 mile = 1.609 km
• 1 pound = 0.454 kg
• 32°F = 0°C, 212°F = 100°C
```

### Расширенные возможности

**1. Multi-step conversions:**
```
Question: "Сколько литров бензина на 100км, если машина делает 30 mpg?"

Claude:
30 miles per gallon (mpg)
= 30 miles / 1 gallon
= 48.3 km / 3.785 liters
= 12.76 km/liter
= 7.84 liters/100km

Ответ: ~7.8 л/100км
```

**2. Context-aware rounding:**
```
Cooking: 2.54 cm → "2.5 см" (1 decimal)
Construction: 2.54 cm → "25 мм" (целые числа удобнее)
Science: 2.54 cm → "2.540 см" (точность)
```

**3. Batch document conversion:**
```
Команда: "Конвертируй все единицы в этом документе в метрические"

Processing technical_spec.docx...
Found 47 measurements
Converted:
- 23 imperial lengths → metric
- 12 weights → metric  
- 8 temperatures → Celsius
- 4 volumes → liters

[Save converted document]
```

---

## Skill #17: Date/Time Wizard
**Уровень сложности:** 🟢 Базовый  
**Приоритет реализации:** 🟢 Низкий  
**Категория:** Простые конвертации

### Описание
Умная работа с датами, временными зонами, форматами дат, расчётами (дедлайны, длительности, календари).

### Проблема которую решает
- Разные форматы дат: DD/MM/YYYY vs MM/DD/YYYY vs YYYY-MM-DD
- Временные зоны: "когда 9am в Токио, сколько в Москве?"
- Расчёты: "сколько рабочих дней до 15 февраля?"
- Относительные даты: "через две недели" → конкретная дата

### Существующие решения

**World Time Buddy:**
✅ Хорошо для timezone conversions
❌ Только Web
❌ Не интегрируется с документами

**Date calculators (timeanddate.com):**
✅ Много возможностей
❌ Медленный Web интерфейс

**Excel формулы:**
```excel
=WORKDAY(TODAY(), 30)  // 30 рабочих дней
```
❌ Нужно знать формулы
❌ Только в Excel

### Как Claude улучшает это

**Естественный язык:**

```
User: "Когда будет полдень в Токио, если у меня 9 утра?"

Claude: "Если у вас 9:00 утра, то в Токио сейчас 17:00 (5 вечера).
        Полдень в Токио наступит когда у вас будет 4:00 утра."

Дополнительно:
Токио: UTC+9
Москва: UTC+3
Разница: 6 часов (Токио впереди)
```

**Умные расчёты:**

```
User: "Сколько рабочих дней до конца квартала?"

Claude (сегодня 27 января 2024):
До конца Q1 (31 марта 2024):
- Календарных дней: 64
- Рабочих дней: 45
- Выходных: 18
- Праздники в период: 1 (8 марта)

Breakdown по месяцам:
- Январь (остаток): 3 рабочих дня
- Февраль: 21 рабочий день
- Март: 21 рабочий день
```

### Конкретные Use Cases

**Use Case 1: Международная команда планирует встречу**
```
Команда в: Москве (3 человека), Лондоне (2), Нью-Йорке (5), Токио (1)

Команда: "Найди время для встречи, подходящее для всех (рабочее время 9-18)"

Claude:
Оптимальные слоты:
1. 11:00 UTC (14:00 Москва, 11:00 Лондон, 06:00 Нью-Йорк, 20:00 Токио)
   ✗ Слишком рано для NY, слишком поздно для Токио

2. 09:00 UTC (12:00 Москва, 09:00 Лондон, 04:00 Нью-Йорк, 18:00 Токио)
   ✓ Подходит для всех (Токио конец дня, остальные в рабочее время)

Рекомендация: 09:00 UTC
Это будет:
- 12:00 (полдень) в Москве
- 09:00 (утро) в Лондоне
- 04:00 (рано утром) в Нью-Йорке ← могут не подойти
- 18:00 (конец дня) в Токио

Альтернатива: Разделить на 2 встречи:
- EMEA/APAC: 09:00 UTC
- Americas/EMEA: 15:00 UTC
```

**Use Case 2: Project deadline planning**
```
Проект стартует: 1 февраля 2024
Нужно завершить: за 6 недель

Команда: "Посчитай дедлайн с учётом выходных и праздников"

Claude:
Старт: 1 февраля 2024 (четверг)

Расчёт:
- 6 недель = 42 календарных дня
- Рабочих дней: 30
- Выходных: 12
- Праздники: 1 (8 марта - Международный женский день в РФ)

Дедлайн: 14 марта 2024 (четверг)

Milestones:
- Week 1 (1-7 фев): 5 рабочих дней
- Week 2 (8-14 фев): 5 рабочих дней
- Week 3 (15-21 фев): 5 рабочих дней
- Week 4 (22-28 фев): 5 рабочих дней
- Week 5 (29 фев - 6 мар): 5 рабочих дней (високосный год!)
- Week 6 (7-13 мар): 4 рабочих дня (8 марта - праздник)
- Buffer до дедлайна: 1 день
```

**Use Case 3: Travel itinerary**
```
Перелёт:
- Вылет: 15 марта, 23:30 из Москвы (SVO)
- Прилёт: 16 марта, 04:45 в Токио (NRT)
- Длительность полёта: 9 часов 15 минут

Команда: "Во сколько я прибуду по московскому времени?"

Claude:
Вылет: 15 марта, 23:30 (Москва, UTC+3)
Прилёт: 16 марта, 04:45 (Токио, UTC+9)

Прилёт по московскому времени: 15 марта, 22:45
(вы как будто прилетите РАНЬШЕ чем вылетели!)

Длительность по часам на руке:
- Вылет в 23:30
- Прилёт в 22:45 (по часам)
- Кажется что прошло -45 минут

Реальная длительность: 9ч 15мин ✓

Jet lag warning:
Разница 6 часов → умеренный джетлаг
Рекомендация: старайтесь спать в самолёте
```

### Технические требования

**Python библиотеки:**
```python
from datetime import datetime, timedelta
import pytz
from dateutil import parser, rrule
import holidays
```

**Базовая реализация:**
```python
class DateTimeWizard:
    def __init__(self):
        self.timezones = {
            'moscow': 'Europe/Moscow',
            'london': 'Europe/London',
            'new_york': 'America/New_York',
            'tokyo': 'Asia/Tokyo',
            'utc': 'UTC'
        }
    
    def convert_timezone(self, time_str, from_tz, to_tz):
        """
        Конвертация между временными зонами
        """
        from_zone = pytz.timezone(self.timezones[from_tz])
        to_zone = pytz.timezone(self.timezones[to_tz])
        
        # Парсим время
        dt = parser.parse(time_str)
        dt = from_zone.localize(dt)
        
        # Конвертируем
        dt_converted = dt.astimezone(to_zone)
        
        return dt_converted.strftime('%Y-%m-%d %H:%M:%S %Z')
    
    def calculate_business_days(self, start_date, end_date, country='RU'):
        """
        Расчёт рабочих дней
        """
        # Получаем праздники для страны
        country_holidays = holidays.country_holidays(country)
        
        # Считаем рабочие дни
        business_days = 0
        current = start_date
        
        while current <= end_date:
            # Проверяем выходной или праздник
            if current.weekday() < 5 and current not in country_holidays:
                business_days += 1
            current += timedelta(days=1)
        
        return business_days
    
    def parse_relative_date(self, relative_text, reference_date=None):
        """
        Парсинг относительных дат
        """
        if reference_date is None:
            reference_date = datetime.now()
        
        # Claude парсит выражения типа "через 2 недели"
        prompt = f"""
        Parse this relative date expression into number of days.
        
        Expression: "{relative_text}"
        Reference date: {reference_date}
        
        Return JSON: {{"days": N, "target_date": "YYYY-MM-DD"}}
        """
        
        result = claude_api(prompt)
        parsed = json.loads(result)
        
        target = reference_date + timedelta(days=parsed['days'])
        return target
```

### Пример интерфейса

```
Date/Time Wizard
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

🕐 Timezone Converter
From: [09:00] [Moscow ▼] [2024-01-27]
To:   [15:00] [Tokyo ▼]  [2024-01-27]

📅 Date Calculator
From: [2024-01-27]
To:   [2024-03-31]

Calculate:
( ) Calendar days
(•) Business days
( ) Hours/Minutes

Result: 45 business days
(Excluding: 18 weekends, 1 holiday)

🌍 Meeting Planner
Participants:
  ☑ Moscow (UTC+3)
  ☑ London (UTC+0)
  ☑ New York (UTC-5)
  ☑ Tokyo (UTC+9)

Working hours: [09:00] - [18:00]

[Find optimal time]
```

### Расширенные возможности

**1. Recurring events:**
```
Команда: "Каждый второй вторник месяца, начиная с февраля"

Claude generates:
2024-02-13 (вт)
2024-03-12 (вт)
2024-04-09 (вт)
2024-05-14 (вт)
...

iCal format export:
RRULE:FREQ=MONTHLY;BYDAY=2TU
```

**2. Calendar availability:**
```
Integration с Google Calendar:

Команда: "Найди свободное время для 1-часовой встречи на этой неделе"

Claude анализирует календарь:
Свободные слоты:
- Понедельник: 14:00-15:00, 16:30-17:30
- Вторник: 10:00-12:00, 15:00-18:00
- Среда: весь день занят
- Четверг: 09:00-10:00, 13:00-17:00
- Пятница: 11:00-16:00
```

---

## Skill #18: Image Format Converter
**Уровень сложности:** 🟡 Средний  
**Приоритет реализации:** 🟡 Средний  
**Категория:** Простые конвертации

### Описание
Пакетная конвертация изображений между форматами (JPG, PNG, WebP, HEIC, SVG) с умным выбором формата, сжатием и оптимизацией.

### Проблема которую решает
- iPhone HEIC фото не открываются на Windows/Android
- Нужно конвертировать PNG в WebP для веб-сайта
- Batch конвертация 1000+ фотографий
- Непонятно какой формат оптимальный для задачи
- Нужно сжать изображения для email/web без потери качества

### Существующие решения

**XnConvert (GUI tool):**
✅ Мощный batch converter
❌ Сложный интерфейс с кучей опций
❌ Нужно вручную выбирать параметры

**ImageMagick (командная строка):**
```bash
convert input.png -quality 85 output.jpg
```
✅ Очень мощный
❌ Сложный синтаксис
❌ Нужно знать оптимальные параметры

**Online converters (cloudconvert.com):**
✅ Простые
❌ Загрузка файлов в интернет (privacy)
❌ Медленно для batch
❌ Лимиты размера/количества

### Как Claude улучшает это

**Умный выбор формата:**

```
Команда: "Подготовь эти фото для веба"

Claude анализирует:
photo1.png (4000x3000, 15MB) - фото с камеры
diagram.png (1200x800, 2MB) - схема с прозрачностью
screenshot.png (1920x1080, 8MB) - скриншот

Рекомендации:
✓ photo1.png → photo1.webp (качество 85%) = 1.2MB
  Причина: WebP лучше сжимает фотографии
  
✓ diagram.png → diagram.png (оптимизировать)= 0.8MB
  Причина: Прозрачность нужна, PNG лучше для диаграмм
  
✓ screenshot.png → screenshot.jpg (качество 90%) = 0.4MB
  Причина: Скриншот без прозрачности, JPG достаточно

Итого: 15MB → 2.4MB (экономия 84%)
```

**Автоматическая оптимизация:**

```
Input: vacation_photo.jpg (5MB, 4000x3000)

Команда: "Подготовь для Instagram"

Claude:
Оптимизация для Instagram:
- Размер: 4000x3000 → 1080x1080 (crop центр)
- Формат: JPG
- Качество: 85%
- Размер файла: 5MB → 320KB

[Preview crop] [Adjust crop area] [Apply]
```

### Конкретные Use Cases

**Use Case 1: Веб-разработчик оптимизирует сайт**
```
Папка: /assets/images/ (120 фотографий, 450MB)

Команда: "Оптимизируй все изображения для веба"

Claude анализирует:
- 80 JPG фотографий (product images)
- 25 PNG логотипов с прозрачностью
- 15 PNG иконок

План оптимизации:
1. JPG → WebP (современные браузеры)
2. JPG fallback (старые браузеры)
3. PNG (логотипы) → оптимизировать, оставить PNG
4. PNG (иконки) → SVG если возможно

Результат:
- 450MB → 85MB (экономия 81%)
- Создана структура:
  images/
    products/
      product1.webp (modern)
      product1.jpg (fallback)
    logos/
      logo.png (оптимизирован)
    icons/
      icon.svg (векторный)
```

**Use Case 2: Фотограф готовит портфолио**
```
Raw photos: 50 файлов .CR3 (Canon RAW)

Команда: "Конвертируй в JPG для портфолио, 
         максимальное качество, watermark"

Claude:
Processing...
✓ IMG_001.CR3 → IMG_001.jpg (качество 95%, watermark added)
✓ IMG_002.CR3 → IMG_002.jpg
...

Settings used:
- Format: JPG
- Quality: 95%
- Size: 4000x3000 (original resolution)
- Watermark: bottom-right corner, 30% opacity
- Color space: sRGB (web standard)
- Metadata: stripped (EXIF removed for privacy)
```

**Use Case 3: iPhone пользователь шарит фото**
```
Ситуация: Сделал 200 фото на iPhone (HEIC format)
         Нужно отправить бабушке на Android

Команда: "Конвертируй все HEIC в JPG для Android"

Claude:
Converting 200 HEIC → JPG
Settings:
- Quality: 92% (balance size/quality)
- Auto-rotate: Yes (based on EXIF)
- Filename: keep original names

Progress: [████████████████████] 200/200

Summary:
- Original: 2.4GB (HEIC)
- Converted: 1.8GB (JPG)
- Compatible with: All devices
- Metadata: preserved (dates, location if desired)
```

### Технические требования

**Python библиотеки:**
```python
from PIL import Image
import pillow_heif  # для HEIC
import cairosvg  # для SVG
from wand.image import Image as WandImage  # ImageMagick wrapper
```

**Базовая архитектура:**
```python
class ImageFormatConverter:
    def __init__(self):
        self.supported_formats = {
            'input': ['jpg', 'jpeg', 'png', 'webp', 'heic', 'svg', 'bmp', 'tiff'],
            'output': ['jpg', 'png', 'webp', 'svg', 'bmp', 'pdf']
        }
    
    def convert(self, input_path, output_format, options=None):
        """
        Конвертация изображения
        """
        options = options or {}
        
        # Открываем изображение
        if input_path.endswith('.heic'):
            heif_file = pillow_heif.read_heif(input_path)
            img = Image.frombytes(
                heif_file.mode, 
                heif_file.size, 
                heif_file.data
            )
        else:
            img = Image.open(input_path)
        
        # Resize если нужно
        if options.get('resize'):
            img = self.resize_image(img, options['resize'])
        
        # Optimize для веба
        if options.get('optimize_for_web'):
            img = self.optimize_for_web(img, output_format)
        
        # Добавить watermark
        if options.get('watermark'):
            img = self.add_watermark(img, options['watermark'])
        
        # Сохраняем в нужном формате
        output_path = input_path.rsplit('.', 1)[0] + f'.{output_format}'
        
        save_options = self.get_save_options(output_format, options)
        img.save(output_path, **save_options)
        
        return output_path
    
    def get_save_options(self, format_name, user_options):
        """
        Оптимальные параметры сохранения для формата
        """
        options = {}
        
        if format_name == 'jpg':
            options['quality'] = user_options.get('quality', 85)
            options['optimize'] = True
            options['progressive'] = True  # Progressive JPEG
        
        elif format_name == 'png':
            options['optimize'] = True
            options['compress_level'] = 9
        
        elif format_name == 'webp':
            options['quality'] = user_options.get('quality', 85)
            options['method'] = 6  # Лучшее сжатие
        
        return options
    
    def resize_image(self, img, target_size):
        """
        Умный resize с сохранением aspect ratio
        """
        if isinstance(target_size, tuple):
            # Точный размер (может crop)
            img.thumbnail(target_size, Image.Resampling.LANCZOS)
        elif isinstance(target_size, int):
            # Max dimension
            img.thumbnail((target_size, target_size), Image.Resampling.LANCZOS)
        
        return img
    
    def optimize_for_web(self, img, format_name):
        """
        Оптимизация для веба
        """
        # Конвертируем в RGB если RGBA (для JPG)
        if format_name == 'jpg' and img.mode == 'RGBA':
            background = Image.new('RGB', img.size, (255, 255, 255))
            background.paste(img, mask=img.split()[3])  # Alpha channel
            img = background
        
        # Resize если слишком большой
        max_dimension = 2000
        if max(img.size) > max_dimension:
            img.thumbnail((max_dimension, max_dimension), Image.Resampling.LANCZOS)
        
        return img
    
    def batch_convert(self, input_dir, output_format, options=None):
        """
        Batch конвертация
        """
        import os
        from pathlib import Path
        
        results = []
        
        # Находим все изображения
        for root, dirs, files in os.walk(input_dir):
            for file in files:
                if any(file.lower().endswith(f'.{fmt}') for fmt in self.supported_formats['input']):
                    input_path = os.path.join(root, file)
                    
                    try:
                        output_path = self.convert(input_path, output_format, options)
                        results.append({
                            'input': input_path,
                            'output': output_path,
                            'status': 'success'
                        })
                    except Exception as e:
                        results.append({
                            'input': input_path,
                            'error': str(e),
                            'status': 'failed'
                        })
        
        return results
```

**Claude рекомендации:**
```python
def claude_recommend_format(image_path, purpose):
    """
    Claude анализирует изображение и рекомендует формат
    """
    img = Image.open(image_path)
    
    info = {
        'size': img.size,
        'mode': img.mode,
        'format': img.format,
        'has_transparency': img.mode in ('RGBA', 'LA', 'PA'),
        'file_size': os.path.getsize(image_path),
    }
    
    prompt = f"""
    Recommend optimal image format for this use case.
    
    Image info:
    - Size: {info['size']}
    - Current format: {info['format']}
    - Has transparency: {info['has_transparency']}
    - File size: {info['file_size'] / 1024:.1f} KB
    
    Purpose: {purpose}
    
    Return JSON:
    {{
      "recommended_format": "webp/jpg/png",
      "quality": 85,
      "reason": "explanation",
      "estimated_size": "200KB"
    }}
    """
    
    recommendation = claude_api(prompt)
    return json.loads(recommendation)
```

### Пример интерфейса

```
Image Format Converter
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Input: [Choose files...] or [Choose folder...]
       Selected: 45 images (150MB)

Output format:
  ( ) JPG - Best for photos
  (•) WebP - Best compression for web
  ( ) PNG - Best for graphics/transparency
  ( ) HEIC → JPG (compatibility)
  ( ) Auto-detect optimal

Options:
  Quality: [85] ▬▬▬●▬▬▬ (higher = larger file)
  
  ☑ Optimize for web
  ☐ Resize to max: [2000] px
  ☐ Add watermark
  ☐ Strip metadata (privacy)
  ☐ Create thumbnails
  
[Preview conversions]

Estimated results:
  Original: 150MB
  Converted: ~35MB (76% reduction)
  Time: ~2 minutes

[Start conversion] [Save settings]
```

### Расширенные возможности

**1. Smart cropping для social media:**
```
Команда: "Подготовь это фото для всех соцсетей"

Claude generates:
- Instagram post: 1080x1080 (квадрат)
- Instagram story: 1080x1920 (вертикаль)
- Facebook cover: 820x312
- Twitter header: 1500x500
- LinkedIn post: 1200x627

All with smart cropping (сохраняет главный объект в кадре)
```

**2. Automatic image enhancement:**
```
Options:
  ☑ Auto white balance
  ☑ Sharpen
  ☑ Denoise
  ☑ Auto contrast
```

**3. Format comparison:**
```
Команда: "Сравни размеры в разных форматах"

Original: image.png (5.2MB)

Comparison:
- JPG quality 85: 850KB (↓84%)
- JPG quality 95: 1.2MB (↓77%)
- WebP quality 85: 620KB (↓88%) ⭐ Best
- WebP lossless: 3.1MB (↓40%)

Recommendation: WebP quality 85
Reason: Лучшее соотношение качество/размер
```

---

**✅ Завершена часть 3! Skills #12-18 детально описаны**

**Прогресс: 18 из 87 skills (21%)**

**Следующие разделы:**
- Skills #19-20: Простые конвертации (завершение)
- Skills #21-39: УРОВЕНЬ 2 — Средний (офисная работа)
- Skills #40-65: УРОВЕНЬ 3 — Продвинутый
- Skills #66-87: УРОВЕНЬ 4 — Профессиональный

**Продолжить с #19-20 или перейти к среднему уровню (#21+)?**
