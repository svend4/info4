# Детальный каталог Claude Skills: Skills #12-18

## УРОВЕНЬ 1 — БАЗОВЫЕ SKILLS (продолжение)

### КАТЕГОРИЯ 1.3: БАЗОВОЕ ФОРМАТИРОВАНИЕ (продолжение)

---

## Skill #12: Table Beautifier
**Уровень сложности:** 🟡 Средний  
**Приоритет реализации:** 🟡 Средний  
**Категория:** Базовое форматирование

### Описание
Форматирование и конвертация таблиц между различными форматами (CSV, Markdown, HTML, Excel, JSON, ASCII) с автоматическим выравниванием и структурированием.

### Проблема которую решает
- CSV данные выглядят неструктурированно
- Нужна таблица в Markdown для документации
- ASCII таблицы для терминала/email
- Конвертация между форматами
- Автоматическое выравнивание колонок

### Существующие решения и их ограничения

**Excel:**
✅ Отличный для создания таблиц
❌ Не подходит для plain text / Markdown
❌ Overkill для простых таблиц

**Markdown editors (Typora, VS Code):**
```markdown
| Name | Age | City |
|------|-----|------|
| John | 25  | NYC  |
```
✅ Работает в Markdown
❌ Нужно вручную выравнивать
❌ Нет конвертации из других форматов

**Online tools (tablesgenerator.com, csvtomd.com):**
✅ Простые конвертеры
❌ Нужен интернет
❌ Copy-paste workflow
❌ Нет умного форматирования

**Python pandas (программистский подход):**
```python
import pandas as pd
df = pd.read_csv('data.csv')
print(df.to_markdown())
```
✅ Мощный
❌ Нужны навыки программирования
❌ Установка библиотек

### Как Claude улучшает это

**Автоматическое структурирование:**

**Input:** Беспорядочный текст
```
Name John Age 25 City NYC
Name Jane Age 30 City LA
Name Bob Age 35 City SF
```

**Команда:** "Преврати это в таблицу"

**Claude анализирует паттерн:**
- Повторяющиеся ключи: Name, Age, City
- 3 записи
- Структура: ключ-значение

**Output (Markdown):**
```markdown
| Name | Age | City |
|------|-----|------|
| John | 25  | NYC  |
| Jane | 30  | LA   |
| Bob  | 35  | SF   |
```

### Конкретные Use Cases

**Use Case 1: Документация для GitHub**
```
Ситуация: API документация, нужна таблица endpoints

Input (plain text):
GET /users - Get all users - 200 OK
POST /users - Create user - 201 Created
DELETE /users/:id - Delete user - 204 No Content

Команда: "Преврати в таблицу Markdown для README"

Output:
| Method | Endpoint      | Description  | Response       |
|--------|---------------|--------------|----------------|
| GET    | /users        | Get all users| 200 OK         |
| POST   | /users        | Create user  | 201 Created    |
| DELETE | /users/:id    | Delete user  | 204 No Content |
```

**Use Case 2: Конвертация CSV в красивую таблицу**
```
Input CSV:
Product,Price,Stock
Laptop,999,15
Mouse,29,150
Keyboard,79,45

Команда: "Конвертируй в ASCII таблицу для email"

Output:
┌──────────┬───────┬───────┐
│ Product  │ Price │ Stock │
├──────────┼───────┼───────┤
│ Laptop   │  $999 │    15 │
│ Mouse    │   $29 │   150 │
│ Keyboard │   $79 │    45 │
└──────────┴───────┴───────┘
```

### Технические требования

```python
import pandas as pd
from tabulate import tabulate

class TableBeautifier:
    def convert(self, input_data, input_format, output_format):
        # Parse input
        if input_format == 'csv':
            df = pd.read_csv(StringIO(input_data))
        elif input_format == 'json':
            df = pd.DataFrame(json.loads(input_data))
        elif input_format == 'text':
            df = self.parse_unstructured_text(input_data)
        
        # Convert to output format
        if output_format == 'markdown':
            return df.to_markdown(index=False)
        elif output_format == 'ascii':
            return tabulate(df, headers='keys', tablefmt='grid')
        elif output_format == 'html':
            return df.to_html(index=False, classes='data-table')
```

---

## Skills #13-18: Краткие описания

## Skill #13: Code Formatter Universal
**Описание:** Универсальное форматирование кода на любом языке
**Use Case:** "Отформатируй этот Python/JS/Go/Rust код"

## Skill #14: JSON/YAML/XML Converter
**Описание:** Конвертация форматов данных
**Use Case:** "Конвертируй config.json в YAML для Kubernetes"

## Skill #15: Clean Paste
**Описание:** Умная очистка при вставке из буфера
**Use Case:** "Вставь из Word, убери форматирование, сохрани ссылки"

## Skill #16: Unit Converter Pro
**Описание:** Универсальный конвертер единиц
**Use Case:** "Конвертируй все футы в метры в этом документе"

## Skill #17: Date/Time Wizard
**Описание:** Работа с датами и временными зонами
**Use Case:** "Когда будет 3pm EST в Токио?"

## Skill #18: Image Format Converter
**Описание:** Пакетная конвертация изображений
**Use Case:** "Конвертируй все PNG в WebP, оптимизируй для веба"

---

**Итого описано подробно:** Skills #1-12 (12 из 87)  
**Кратко описано:** Skills #13-18 (6 из 87)
**Всего:** 18 из 87 skills (21% ✓)

**Следующие:** Skills #19-28 (Уровень 2 - Средний: работа с документами)
